import { DFA, DFALanguagePreset, AlphabetType } from '../types/automata';
import { PRESET_EXAMPLES } from './presets';
import {
  combineDFAs,
  complementDFA,
  createContainsSubstringDFA,
  createCountModuloDFA,
  createDivisibilityDFA,
  createEndsWithDFA,
  createExactStringDFA,
  createLastDigitDFA,
  createLengthModuloDFA,
  createStartsWithDFA,
} from '../utils/dfaGenerators';

const BINARY = ['0', '1'];
const DECIMAL = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

function makePreset(
  dfa: DFA,
  category: string,
  alphabetType: AlphabetType,
  languageDescription = dfa.description,
  examples: string[] = alphabetType === 'binary' ? ['0', '01', '10', '101'] : ['0', '2', '10', '15'],
  nonExamples: string[] = alphabetType === 'binary' ? ['', '1', '00', '11'] : ['', '1', '3', '11'],
): DFALanguagePreset {
  const epsilonNote = dfa.finalStates.includes(dfa.initialState) ? 'ε is accepted.' : 'ε is rejected.';
  return { ...dfa, category, alphabetType, languageDescription: `${languageDescription} ${epsilonNote}`, examples, nonExamples };
}

const library = new Map<string, DFALanguagePreset>();
function add(dfa: DFA, category: string, alphabetType: AlphabetType, examples?: string[], nonExamples?: string[]): DFALanguagePreset {
  const preset = makePreset(dfa, category, alphabetType, dfa.description, examples, nonExamples);
  if (!library.has(preset.id)) library.set(preset.id, preset);
  return library.get(preset.id)!;
}

function complementLabel(name: string): string {
  if (name.includes('Starts with')) return name.replace('Starts with', 'Does NOT start with');
  if (name.includes('Ends with')) return name.replace('Ends with', 'Does NOT end with');
  if (name.includes('Contains substring')) return name.replace('Contains substring', 'Does NOT contain substring');
  if (name.includes('Divisible by')) return name.replace('Divisible by', 'NOT divisible by');
  if (name.includes('Even number')) return name.replace('Even number', 'NOT even number');
  if (name.includes('Odd number')) return name.replace('Odd number', 'NOT odd number');
  return name.replace(' — ', ' — NOT ');
}

function addWithComplement(dfa: DFA, category: string, alphabetType: AlphabetType, examples?: string[], nonExamples?: string[]) {
  add(dfa, category, alphabetType, examples, nonExamples);
  add(complementDFA(dfa, complementLabel(dfa.name)), 'Complement / NOT', alphabetType, nonExamples, examples);
}

const binaryStarts = {
  '0': createStartsWithDFA(['0'], BINARY, 'Binary — Starts with 0'),
  '1': createStartsWithDFA(['1'], BINARY, 'Binary — Starts with 1'),
};
const binaryEnds = {
  '0': createEndsWithDFA(['0'], BINARY, 'Binary — Ends with 0'),
  '1': createEndsWithDFA(['1'], BINARY, 'Binary — Ends with 1'),
};
for (const symbol of ['0', '1'] as const) {
  addWithComplement(binaryStarts[symbol], 'Start / End', 'binary', symbol === '0' ? ['0', '01', '001', '0101'] : ['1', '10', '101'], symbol === '0' ? ['1', '10', '110'] : ['0', '01', '001']);
  addWithComplement(binaryEnds[symbol], 'Start / End', 'binary', symbol === '0' ? ['0', '10', '110'] : ['1', '01', '101'], symbol === '0' ? ['', '1', '11'] : ['', '0', '00']);
}

for (const startSymbol of ['0', '1'] as const) {
  for (const endSymbol of ['0', '1'] as const) {
    const both = combineDFAs(binaryStarts[startSymbol], binaryEnds[endSymbol], 'intersection', `Binary — Starts with ${startSymbol} AND ends with ${endSymbol}`);
    const either = combineDFAs(binaryStarts[startSymbol], binaryEnds[endSymbol], 'union', `Binary — Starts with ${startSymbol} OR ends with ${endSymbol}`);
    addWithComplement(both, 'Start / End', 'binary');
    add(either, 'Start / End', 'binary');
  }
}

const substrings = ['0', '1', '00', '01', '10', '11', '000', '001', '010', '011', '100', '101', '110', '111'];
const substringDfas = new Map<string, DFA>();
for (const pattern of substrings) {
  const dfa = createContainsSubstringDFA(pattern.split(''), BINARY, `Binary — Contains substring ${pattern}`);
  substringDfas.set(pattern, dfa);
  addWithComplement(dfa, 'Substrings & Patterns', 'binary', pattern === '01' ? ['01', '001', '0101'] : [pattern, `1${pattern}0`], ['', pattern === '0' ? '1' : '0', `1${pattern === '0' ? '1' : '0'}`]);
}
for (const patterns of [['01', '10'], ['00', '11']]) {
  const combined = combineDFAs(substringDfas.get(patterns[0])!, substringDfas.get(patterns[1])!, 'union', `Binary — Contains ${patterns[0]} OR ${patterns[1]}`);
  add(combined, 'Substrings & Patterns', 'binary');
}
for (const pattern of ['01', '10', '00', '11']) {
  addWithComplement(createStartsWithDFA(pattern.split(''), BINARY, `Binary — Starts with ${pattern}`), 'Prefix / Suffix', 'binary');
  addWithComplement(createEndsWithDFA(pattern.split(''), BINARY, `Binary — Ends with ${pattern}`), 'Prefix / Suffix', 'binary');
}

const countLanguages = [
  ['0', 'Even number of 0s', 0], ['0', 'Odd number of 0s', 1],
  ['1', 'Even number of 1s', 0], ['1', 'Odd number of 1s', 1],
] as const;
for (const [symbol, label, residue] of countLanguages) {
  const dfa = createCountModuloDFA(BINARY, symbol, 2, residue, `Binary — ${label}`);
  addWithComplement(dfa, 'Parity / Counting', 'binary', residue === 0 ? ['', '00', '11', '0101'] : [symbol, `${symbol}0`, `${symbol}1`], residue === 0 ? ['0', '1', '01'] : ['', '00', '11']);
}
for (const [modulus, residues] of [[2, [0, 1]], [3, [0, 1, 2]], [4, [0, 1, 2, 3]]] as const) {
  for (const residue of residues) {
    const dfa = createLengthModuloDFA(BINARY, modulus, residue, `Binary — Length mod ${modulus} = ${residue}`);
    addWithComplement(dfa, 'Modulo / Length', 'binary', residue === 0 ? ['', '0'.repeat(modulus)] : ['0'.repeat(residue)], ['0'.repeat((residue + 1) % modulus)]);
  }
}

for (const divisor of [2, 3, 4, 5, 6]) {
  const dfa = createDivisibilityDFA(BINARY, 2, divisor, `Binary — Divisible by ${divisor}`);
  addWithComplement(dfa, 'Divisibility', 'binary', ['', '0', '1'.repeat(divisor)], ['1', '10', '11']);
}
const binaryDiv2 = library.get('divisible_by_2_2')!;
const binaryDiv3 = library.get('divisible_by_2_3')!;
add(combineDFAs(binaryDiv2, binaryDiv3, 'intersection', 'Binary — Divisible by 2 AND 3'), 'Divisibility', 'binary');
add(combineDFAs(binaryDiv2, binaryDiv3, 'difference', 'Binary — Divisible by 2 but NOT 3'), 'Complement / NOT', 'binary');
add(combineDFAs(binaryDiv3, binaryDiv2, 'difference', 'Binary — Divisible by 3 but NOT 2'), 'Complement / NOT', 'binary');
add(combineDFAs(binaryDiv2, binaryDiv3, 'union', 'Binary — Divisible by 2 OR 3'), 'Divisibility', 'binary');

for (const [modulus, residues] of [[2, [0, 1]], [3, [0, 1, 2]], [4, [0, 1, 2, 3]]] as const) {
  for (const residue of residues) {
    add(createCountModuloDFA(BINARY, '0', modulus, residue, `Binary — Number of 0s mod ${modulus} = ${residue}`), 'Modulo / Counting', 'binary');
    add(createCountModuloDFA(BINARY, '1', modulus, residue, `Binary — Number of 1s mod ${modulus} = ${residue}`), 'Modulo / Counting', 'binary');
  }
}

for (const digit of DECIMAL) {
  add(createLastDigitDFA(DECIMAL, [digit], `Decimal — Ends with ${digit}`), 'Last Digit', 'decimal', [digit, `1${digit}`, `20${digit}`], ['', '1', '3']);
}
const decimalEndsWith0 = createLastDigitDFA(DECIMAL, ['0'], 'Decimal — Ends with 0');
const decimalEndsWith5 = createLastDigitDFA(DECIMAL, ['5'], 'Decimal — Ends with 5');
add(decimalEndsWith0, 'Last Digit', 'decimal', ['0', '10', '20'], ['1', '5']);
add(complementDFA(decimalEndsWith0, 'Decimal — Does NOT end with 0'), 'Complement / NOT', 'decimal', ['1', '5', '12'], ['0', '10']);
add(decimalEndsWith5, 'Last Digit', 'decimal', ['5', '15', '25'], ['0', '2']);
add(complementDFA(decimalEndsWith5, 'Decimal — Does NOT end with 5'), 'Complement / NOT', 'decimal', ['0', '2', '14'], ['5', '15']);
const decimalEven = createLastDigitDFA(DECIMAL, ['0', '2', '4', '6', '8'], 'Decimal — Even final digit');
const decimalOdd = createLastDigitDFA(DECIMAL, ['1', '3', '5', '7', '9'], 'Decimal — Odd final digit');
add(decimalEven, 'Parity', 'decimal', ['0', '2', '14'], ['1', '3', '15']);
add(complementDFA(decimalEven, 'Decimal — NOT even final digit'), 'Complement / NOT', 'decimal', ['1', '3', '15'], ['0', '2', '14']);
add(decimalOdd, 'Parity', 'decimal', ['1', '3', '15'], ['0', '2', '14']);
add(complementDFA(decimalOdd, 'Decimal — NOT odd final digit'), 'Complement / NOT', 'decimal', ['0', '2', '14'], ['1', '3', '15']);

for (const divisor of [2, 3, 4, 5, 6, 9, 10]) {
  const dfa = createDivisibilityDFA(DECIMAL, 10, divisor, `Decimal — Divisible by ${divisor}`);
  addWithComplement(dfa, 'Divisibility', 'decimal', ['', '0', String(divisor * 2)], ['1', String(divisor + 1), '11']);
}
for (const [modulus, residues] of [[2, [0, 1]], [3, [0, 1, 2]], [4, [0, 1, 2, 3]], [5, [0, 1, 2, 3, 4]]] as const) {
  for (const residue of residues) {
    const dfa = createDivisibilityDFA(DECIMAL, 10, modulus, `Decimal — Number mod ${modulus} = ${residue}`);
    const adjusted = { ...dfa, id: `decimal_mod_${modulus}_${residue}`, description: `L = { w | numeric value(w) mod ${modulus} = ${residue} }`, finalStates: [`remainder_${residue}`] };
    add(adjusted, 'Modulo', 'decimal');
  }
}

for (const word of ['000', '010', '101', '111', '0000', '0110', '1001', '1111']) {
  add(createExactStringDFA(word, BINARY, `Binary — Exact palindrome ${word}`), 'Finite Palindrome', 'binary', [word], ['', word.slice(0, -1), `${word}0`]);
}

// Keep the original examples available as individual library entries too.
for (const preset of PRESET_EXAMPLES) {
  for (const dfa of [preset.m1, preset.m2]) {
    const isBinary = dfa.alphabet.length === 2 && dfa.alphabet.every((symbol) => ['0', '1'].includes(symbol));
    const isDecimal = dfa.alphabet.length === 10 && dfa.alphabet.every((symbol) => DECIMAL.includes(symbol));
    const alphabetType: AlphabetType = isDecimal ? 'decimal' : isBinary ? 'binary' : 'custom';
    add(dfa, 'Featured Examples', alphabetType, preset.recommendedTestStrings.filter(Boolean).slice(0, 4), ['', '0', '1']);
  }
}

export const DFA_LANGUAGE_LIBRARY: DFALanguagePreset[] = Array.from(library.values());
export const BINARY_ALPHABET = BINARY;
export const DECIMAL_ALPHABET = DECIMAL;
