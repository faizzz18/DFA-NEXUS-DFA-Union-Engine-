export interface DFA {
  id: string;
  name: string;
  description: string;
  states: string[];
  alphabet: string[];
  initialState: string;
  finalStates: string[];
  // transitions[state][symbol] = nextState
  transitions: Record<string, Record<string, string>>;
}

export type AlphabetType = 'binary' | 'decimal' | 'custom';

export interface DFALanguagePreset extends DFA {
  category: string;
  alphabetType: AlphabetType;
  languageDescription: string;
  examples: string[];
  nonExamples: string[];
}

export type OperationMode = 'union' | 'intersection' | 'difference' | 'symmetric_difference';

export interface ProductStateMetadata {
  id: string;
  q1: string;
  q2: string;
  isInitial: boolean;
  isAcceptingM1: boolean;
  isAcceptingM2: boolean;
  isAcceptingUnion: boolean;
  isAcceptingIntersection: boolean;
  isAcceptingDifference: boolean;
  isAcceptingSymDiff: boolean;
  isReachable: boolean;
  depth: number;
}

export interface ProductDFA extends DFA {
  productStatesMeta: Record<string, ProductStateMetadata>;
  allCartesianStatesCount: number;
  reachableStatesCount: number;
  operationMode: OperationMode;
}

export interface SimulationStep {
  stepIndex: number;
  symbol: string | null; // null for step 0 (initial)
  remainingInput: string;
  consumedInput: string;
  m1State: string;
  m1NextState?: string;
  m1IsAccepting: boolean;
  m2State: string;
  m2NextState?: string;
  m2IsAccepting: boolean;
  productState: string;
  productNextState?: string;
  productIsAccepting: boolean;
  explanation: string;
}

export interface SimulationResult {
  inputString: string;
  steps: SimulationStep[];
  m1Accepted: boolean;
  m2Accepted: boolean;
  unionAccepted: boolean;
  operationAccepted: boolean;
  finalProductState: string;
}

export interface TestCase {
  id: string;
  input: string;
  expectedM1?: boolean;
  expectedM2?: boolean;
  expectedUnion?: boolean;
  notes?: string;
}

export interface PresetDFAExample {
  id: string;
  title: string;
  summary: string;
  category: string;
  m1: DFA;
  m2: DFA;
  recommendedTestStrings: string[];
  vivaInsight: string;
}
