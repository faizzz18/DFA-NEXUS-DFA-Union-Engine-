import React, { useState } from 'react';
import { DFA, OperationMode, ProductDFA } from '../types/automata';
import { Filter, Eye, Layers, CheckCircle2, XCircle } from 'lucide-react';

interface ProductTransitionTableProps {
  m1: DFA;
  m2: DFA;
  productDfa: ProductDFA;
  reachableOnly: boolean;
  onToggleReachableOnly: (reachableOnly: boolean) => void;
  operationMode: OperationMode;
  onChangeOperationMode: (mode: OperationMode) => void;
  activeProductState?: string;
}

export const ProductTransitionTable: React.FC<ProductTransitionTableProps> = ({
  m1,
  m2,
  productDfa,
  reachableOnly,
  onToggleReachableOnly,
  operationMode,
  onChangeOperationMode,
  activeProductState,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  // Collect states to display
  const allCartesianStateIds = Object.keys(productDfa.productStatesMeta);
  const displayedStateIds = allCartesianStateIds.filter((id) => {
    const meta = productDfa.productStatesMeta[id];
    if (reachableOnly && !meta.isReachable) return false;
    if (searchQuery && !id.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  const reachableCount = productDfa.reachableStatesCount;
  const totalCount = productDfa.allCartesianStatesCount;
  const unreachableCount = totalCount - reachableCount;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden flex flex-col">
      {/* Header & Controls Bar */}
      <div className="p-4 bg-slate-950 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-slate-100 text-sm">Product Transition Matrix δ</h3>
            <span className="text-xs text-slate-500 font-mono">Q = Q₁ × Q₂</span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Transitions computed in parallel: δ((q, p), a) = (δ₁(q, a), δ₂(p, a))
          </p>
        </div>

        {/* Operation Mode Selector */}
        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800 shrink-0">
          <button
            type="button"
            onClick={() => onChangeOperationMode('union')}
            className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
              operationMode === 'union'
                ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Union (OR)
          </button>
          <button
            type="button"
            onClick={() => onChangeOperationMode('intersection')}
            className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
              operationMode === 'intersection'
                ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Intersection (AND)
          </button>
          <button
            type="button"
            onClick={() => onChangeOperationMode('difference')}
            className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
              operationMode === 'difference'
                ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            M₁ \ M₂
          </button>
          <button
            type="button"
            onClick={() => onChangeOperationMode('symmetric_difference')}
            className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
              operationMode === 'symmetric_difference'
                ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            XOR (⊕)
          </button>
        </div>
      </div>

      {/* Filter and Reachability Toggle Bar */}
      <div className="px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-slate-400">Total Cartesian States:</span>
            <span className="font-mono font-semibold text-slate-200">
              |Q₁| × |Q₂| = {m1.states.length} × {m2.states.length} = {totalCount}
            </span>
          </div>
          <span className="text-slate-700">·</span>
          <div className="flex items-center gap-2">
            <span className="text-slate-400">Reachable:</span>
            <span className="font-mono font-semibold text-emerald-400">{reachableCount}</span>
            {unreachableCount > 0 && (
              <span className="text-slate-400">({unreachableCount} unreachable)</span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Reachable Only Toggle */}
          <label className="flex items-center gap-2 cursor-pointer text-slate-300">
            <input
              type="checkbox"
              checked={reachableOnly}
              onChange={(e) => onToggleReachableOnly(e.target.checked)}
              className="rounded bg-slate-950 border-slate-700 text-indigo-600 focus:ring-0 focus:ring-offset-0"
            />
            <span>Reachable States Only</span>
          </label>

          {/* Quick Search */}
          <input
            type="text"
            placeholder="Search state..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-slate-950 border border-slate-700 rounded px-2.5 py-1 text-xs font-mono text-slate-200 placeholder-slate-500 w-32 focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Table Content */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs font-mono">
          <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
            <tr>
              <th className="py-2.5 px-3">State (q, p)</th>
              <th className="py-2.5 px-3">Status</th>
              <th className="py-2.5 px-3">BFS Depth</th>
              <th className="py-2.5 px-3">q ∈ F₁</th>
              <th className="py-2.5 px-3">p ∈ F₂</th>
              <th className="py-2.5 px-3">
                {operationMode === 'union' && 'q ∈ F₁ ∨ p ∈ F₂'}
                {operationMode === 'intersection' && 'q ∈ F₁ ∧ p ∈ F₂'}
                {operationMode === 'difference' && 'q ∈ F₁ ∧ p ∉ F₂'}
                {operationMode === 'symmetric_difference' && 'q ∈ F₁ ⊕ p ∈ F₂'}
              </th>
              {productDfa.alphabet.map((symbol) => (
                <th key={symbol} className="py-2.5 px-3 font-semibold text-slate-300">
                  δ((q, p), {symbol})
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-slate-300">
            {displayedStateIds.map((id) => {
              const meta = productDfa.productStatesMeta[id];
              const isInitial = meta.isInitial;
              const isAccepting = productDfa.finalStates.includes(id);
              const isActive = activeProductState === id;

              return (
                <tr
                  key={id}
                  className={`transition-colors ${
                    isActive
                      ? 'bg-indigo-950/60 text-white font-semibold'
                      : !meta.isReachable
                      ? 'opacity-50 bg-slate-950/40'
                      : 'hover:bg-slate-800/40'
                  }`}
                >
                  <td className="py-2.5 px-3 font-semibold">
                    <div className="flex items-center gap-1.5">
                      {isInitial && <span className="text-indigo-400 font-bold">→</span>}
                      {isAccepting && <span className="text-emerald-400 font-bold">*</span>}
                      <span className={isAccepting ? 'text-emerald-300' : 'text-slate-200'}>
                        {id}
                      </span>
                    </div>
                  </td>
                  <td className="py-2.5 px-3">
                    {meta.isReachable ? (
                      <span className="text-emerald-400">Reachable</span>
                    ) : (
                      <span className="text-amber-500">Unreachable</span>
                    )}
                  </td>
                  <td className="py-2.5 px-3">
                    {meta.isReachable ? meta.depth : <span className="text-slate-600">∞</span>}
                  </td>
                  <td className="py-2.5 px-3">
                    {meta.isAcceptingM1 ? (
                      <span className="text-emerald-400">Yes</span>
                    ) : (
                      <span className="text-slate-500">No</span>
                    )}
                  </td>
                  <td className="py-2.5 px-3">
                    {meta.isAcceptingM2 ? (
                      <span className="text-emerald-400">Yes</span>
                    ) : (
                      <span className="text-slate-500">No</span>
                    )}
                  </td>
                  <td className="py-2.5 px-3">
                    {isAccepting ? (
                      <span className="text-emerald-400 font-bold">YES (Accept)</span>
                    ) : (
                      <span className="text-rose-400">NO (Reject)</span>
                    )}
                  </td>
                  {productDfa.alphabet.map((symbol) => {
                    const nextState = productDfa.transitions[id]?.[symbol] ?? '-';
                    return (
                      <td key={symbol} className="py-2.5 px-3 text-indigo-300">
                        {nextState}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Legend Footer */}
      <div className="p-3 bg-slate-950 text-[11px] text-slate-400 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-4">
          <span>Notation: → indicates Initial State</span>
          <span className="text-slate-700">·</span>
          <span>* indicates Accepting / Final State</span>
          <span className="text-slate-700">·</span>
          <span>Reachable states determined by BFS from ({m1.initialState}, {m2.initialState})</span>
        </div>
      </div>
    </div>
  );
};
