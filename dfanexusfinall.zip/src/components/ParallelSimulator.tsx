import React, { useState, useEffect, useRef } from 'react';
import { DFA, ProductDFA, SimulationResult, SimulationStep } from '../types/automata';
import { simulateParallel } from '../utils/automataEngine';
import {
  Play,
  Pause,
  SkipForward,
  SkipBack,
  RotateCcw,
  CheckCircle2,
  XCircle,
  HelpCircle,
  ArrowRight,
  Sparkles,
} from 'lucide-react';

interface ParallelSimulatorProps {
  m1: DFA;
  m2: DFA;
  productDfa: ProductDFA;
  currentInputString?: string;
  onCurrentInputChange?: (str: string) => void;
  onActiveStateChange?: (states: {
    m1State?: string;
    m2State?: string;
    productState?: string;
    activeTransition?: {
      m1?: { from: string; to: string; symbol: string };
      m2?: { from: string; to: string; symbol: string };
      product?: { from: string; to: string; symbol: string };
    };
  }) => void;
  quickTestStrings?: string[];
}

export const ParallelSimulator: React.FC<ParallelSimulatorProps> = ({
  m1,
  m2,
  productDfa,
  currentInputString,
  onCurrentInputChange,
  onActiveStateChange,
  quickTestStrings = ['', '0', '1', '01', '10', '00', '11', '010', '101', '1100'],
}) => {
  const [internalInputString, setInternalInputString] = useState<string>(
    currentInputString ?? (quickTestStrings.length > 3 ? quickTestStrings[3] : '010')
  );
  const inputString = currentInputString !== undefined ? currentInputString : internalInputString;

  useEffect(() => {
    if (currentInputString !== undefined) {
      setInternalInputString(currentInputString);
      setCurrentStepIndex(0);
      setIsPlaying(false);
    }
  }, [currentInputString]);

  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1000); // ms per step

  // Compute simulation result
  const simResult: SimulationResult = React.useMemo(() => {
    return simulateParallel(m1, m2, productDfa, inputString);
  }, [m1, m2, productDfa, inputString]);

  const currentStep: SimulationStep = simResult.steps[currentStepIndex] || simResult.steps[0];
  const isAtEnd = currentStepIndex === simResult.steps.length - 1;
  const isAtStart = currentStepIndex === 0;

  // Sync active states to parent canvas viewers
  useEffect(() => {
    if (!currentStep) return;

    const prevStep = currentStepIndex > 0 ? simResult.steps[currentStepIndex - 1] : null;
    const symbol = currentStep.symbol;

    onActiveStateChange?.({
      m1State: currentStep.m1State,
      m2State: currentStep.m2State,
      productState: currentStep.productState,
      activeTransition:
        prevStep && symbol
          ? {
              m1: { from: prevStep.m1State, to: currentStep.m1State, symbol },
              m2: { from: prevStep.m2State, to: currentStep.m2State, symbol },
              product: { from: prevStep.productState, to: currentStep.productState, symbol },
            }
          : undefined,
    });
  }, [currentStepIndex, currentStep, simResult, onActiveStateChange]);

  // Autoplay timer
  useEffect(() => {
    let interval: any = null;
    if (isPlaying) {
      if (isAtEnd) {
        setIsPlaying(false);
      } else {
        interval = setInterval(() => {
          setCurrentStepIndex((prev) => {
            if (prev >= simResult.steps.length - 1) {
              setIsPlaying(false);
              return prev;
            }
            return prev + 1;
          });
        }, playbackSpeed);
      }
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isPlaying, isAtEnd, simResult.steps.length, playbackSpeed]);

  const handleStepForward = () => {
    if (currentStepIndex < simResult.steps.length - 1) {
      setCurrentStepIndex((c) => c + 1);
    }
  };

  const handleStepBack = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex((c) => c - 1);
    }
  };

  const handleReset = () => {
    setIsPlaying(false);
    setCurrentStepIndex(0);
  };

  const handleInputChange = (newVal: string) => {
    setInternalInputString(newVal);
    onCurrentInputChange?.(newVal);
    setCurrentStepIndex(0);
    setIsPlaying(false);
  };

  // Determine current tape symbol index
  // Step 0 is start (no symbol read yet). Step 1 reads inputString[0], etc.
  const activeSymbolIndex = currentStepIndex - 1;

  return (
    <div className="flex flex-col gap-4 w-full">
      {/* Input Control & Tape Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 flex-1 min-w-[280px]">
            <label htmlFor="sim-input" className="text-xs font-semibold text-slate-300 shrink-0">
              Input String w:
            </label>
            <div className="relative flex-1">
              <input
                id="sim-input"
                type="text"
                value={inputString}
                onChange={(e) => handleInputChange(e.target.value)}
                placeholder="Enter string (e.g. 010 or empty for ε)"
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 font-mono text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
              />
              {inputString.length === 0 && (
                <span className="absolute right-3 top-2 text-xs font-mono text-slate-500 pointer-events-none">
                  ε (empty string)
                </span>
              )}
            </div>
            <span className="text-xs font-mono text-slate-500 shrink-0">
              Length: {inputString.length}
            </span>
          </div>

          {/* Quick presets for this alphabet */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-xs text-indigo-400 font-medium mr-1 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-indigo-400" />
              <span>Recommended ({quickTestStrings.length}):</span>
            </span>
            {quickTestStrings.map((str, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleInputChange(str)}
                className={`px-2 py-0.5 text-xs font-mono rounded border transition-colors ${
                  inputString === str
                    ? 'bg-indigo-600 text-white border-indigo-400 font-bold shadow-sm'
                    : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                }`}
                title={`Load "${str === '' ? 'ε' : str}" into tape`}
              >
                {str === '' ? 'ε' : str}
              </button>
            ))}
          </div>
        </div>

        {/* Visual Tape Display */}
        <div className="bg-slate-950 border border-slate-800/80 rounded p-3 flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Input Tape Execution:</span>
            <span>
              Step {currentStepIndex} of {simResult.steps.length - 1}
            </span>
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto py-1">
            {/* Start Symbol Marker */}
            <div
              className={`flex flex-col items-center justify-center w-9 h-11 rounded border font-mono text-xs transition-colors shrink-0 ${
                currentStepIndex === 0
                  ? 'bg-indigo-950/80 border-indigo-500 text-indigo-300 ring-2 ring-indigo-500/30'
                  : 'bg-slate-900 border-slate-800 text-slate-500'
              }`}
            >
              <span className="text-[9px] text-slate-500">START</span>
              <span className="font-semibold">▷</span>
            </div>

            {inputString.length === 0 ? (
              <div
                className={`flex flex-col items-center justify-center px-4 h-11 rounded border font-mono text-xs transition-colors shrink-0 ${
                  currentStepIndex === 0
                    ? 'bg-indigo-950/80 border-indigo-500 text-indigo-300'
                    : 'bg-slate-900 border-slate-800 text-slate-500'
                }`}
              >
                <span className="text-[9px] text-slate-500">EPSILON</span>
                <span className="font-semibold">ε</span>
              </div>
            ) : (
              inputString.split('').map((char, idx) => {
                const isCurrent = idx === activeSymbolIndex;
                const isConsumed = idx < activeSymbolIndex;

                return (
                  <div
                    key={idx}
                    className={`flex flex-col items-center justify-center w-9 h-11 rounded border font-mono text-sm transition-all shrink-0 ${
                      isCurrent
                        ? 'bg-indigo-600 border-indigo-400 text-white font-bold ring-2 ring-indigo-400/40 shadow-lg scale-105'
                        : isConsumed
                        ? 'bg-slate-900 border-slate-700/60 text-slate-400 opacity-70'
                        : 'bg-slate-900/60 border-slate-800 text-slate-300'
                    }`}
                  >
                    <span className="text-[9px] text-slate-500">w[{idx}]</span>
                    <span>{char}</span>
                  </div>
                );
              })
            )}

            {/* End of Tape Marker */}
            <div
              className={`flex flex-col items-center justify-center w-9 h-11 rounded border font-mono text-xs transition-colors shrink-0 ${
                isAtEnd && inputString.length > 0
                  ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300 ring-2 ring-emerald-500/30'
                  : 'bg-slate-900 border-slate-800 text-slate-500'
              }`}
            >
              <span className="text-[9px] text-slate-500">END</span>
              <span className="font-semibold">⊣</span>
            </div>
          </div>
        </div>

        {/* Playback Controls & Speed */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-slate-800">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={handleReset}
              disabled={isAtStart}
              className="p-1.5 text-slate-300 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:hover:bg-slate-800 rounded border border-slate-700 transition-colors"
              title="Reset to beginning"
              aria-label="Reset tape"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleStepBack}
              disabled={isAtStart}
              className="p-1.5 text-slate-300 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:hover:bg-slate-800 rounded border border-slate-700 transition-colors"
              title="Previous Step"
              aria-label="Step back"
            >
              <SkipBack className="w-4 h-4" />
            </button>

            {isPlaying ? (
              <button
                type="button"
                onClick={() => setIsPlaying(false)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded font-medium text-xs transition-colors"
              >
                <Pause className="w-3.5 h-3.5" />
                <span>Pause</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  if (isAtEnd) setCurrentStepIndex(0);
                  setIsPlaying(true);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded font-medium text-xs transition-colors shadow-sm"
              >
                <Play className="w-3.5 h-3.5" />
                <span>{isAtEnd ? 'Replay' : 'Play'}</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleStepForward}
              disabled={isAtEnd}
              className="p-1.5 text-slate-300 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:hover:bg-slate-800 rounded border border-slate-700 transition-colors"
              title="Next Step"
              aria-label="Step forward"
            >
              <SkipForward className="w-4 h-4" />
            </button>
          </div>

          {/* Speed Selector */}
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span>Speed:</span>
            {[
              { label: '0.5x', speed: 1600 },
              { label: '1x', speed: 900 },
              { label: '2x', speed: 450 },
            ].map((item) => (
              <button
                key={item.label}
                type="button"
                onClick={() => setPlaybackSpeed(item.speed)}
                className={`px-2 py-0.5 rounded text-xs transition-colors ${
                  playbackSpeed === item.speed
                    ? 'bg-slate-700 text-slate-100 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Synchronous 3-Machine Parallel Processing Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* Machine M1 Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-semibold text-cyan-400">DFA M₁</span>
              <span className="text-[11px] text-slate-400 font-mono">
                {m1.finalStates.includes(currentStep.m1State) ? 'State ∈ F₁' : 'State ∉ F₁'}
              </span>
            </div>
            <div className="mt-3 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-500 block uppercase">Current State</span>
                <span className="text-xl font-mono font-bold text-slate-100">
                  {currentStep.m1State}
                </span>
              </div>
              <div
                className={`px-2 py-1 rounded text-xs font-medium flex items-center gap-1 ${
                  currentStep.m1IsAccepting
                    ? 'bg-emerald-950/70 text-emerald-400 border border-emerald-800/80'
                    : 'bg-slate-800/80 text-slate-400 border border-slate-700'
                }`}
              >
                {currentStep.m1IsAccepting ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Accepting</span>
                  </>
                ) : (
                  <>
                    <XCircle className="w-3.5 h-3.5" />
                    <span>Non-accepting</span>
                  </>
                )}
              </div>
            </div>
            <p className="mt-2 text-xs text-slate-400 line-clamp-2">{m1.description}</p>
          </div>
          <div className="mt-3 pt-2 border-t border-slate-800/70 text-[11px] text-slate-500 font-mono">
            Final Set F₁ = {'{' + m1.finalStates.join(', ') + '}'}
          </div>
        </div>

        {/* Machine M2 Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-semibold text-amber-400">DFA M₂</span>
              <span className="text-[11px] text-slate-400 font-mono">
                {m2.finalStates.includes(currentStep.m2State) ? 'State ∈ F₂' : 'State ∉ F₂'}
              </span>
            </div>
            <div className="mt-3 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-500 block uppercase">Current State</span>
                <span className="text-xl font-mono font-bold text-slate-100">
                  {currentStep.m2State}
                </span>
              </div>
              <div
                className={`px-2 py-1 rounded text-xs font-medium flex items-center gap-1 ${
                  currentStep.m2IsAccepting
                    ? 'bg-emerald-950/70 text-emerald-400 border border-emerald-800/80'
                    : 'bg-slate-800/80 text-slate-400 border border-slate-700'
                }`}
              >
                {currentStep.m2IsAccepting ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Accepting</span>
                  </>
                ) : (
                  <>
                    <XCircle className="w-3.5 h-3.5" />
                    <span>Non-accepting</span>
                  </>
                )}
              </div>
            </div>
            <p className="mt-2 text-xs text-slate-400 line-clamp-2">{m2.description}</p>
          </div>
          <div className="mt-3 pt-2 border-t border-slate-800/70 text-[11px] text-slate-500 font-mono">
            Final Set F₂ = {'{' + m2.finalStates.join(', ') + '}'}
          </div>
        </div>

        {/* Product / Union DFA Card */}
        <div className="bg-slate-900 border border-indigo-900/60 rounded-lg p-3.5 flex flex-col justify-between shadow-sm">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-indigo-900/40">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-semibold text-indigo-400">Parallel Product DFA</span>
                <span className="text-[10px] text-indigo-300/80 bg-indigo-950 px-1.5 py-0.2 rounded border border-indigo-800/50">
                  M₁ ∪ M₂
                </span>
              </div>
              <span className="text-[11px] font-mono text-slate-400">
                {currentStep.productIsAccepting ? 'State ∈ F_union' : 'State ∉ F_union'}
              </span>
            </div>

            <div className="mt-3 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-500 block uppercase">Product State (q, p)</span>
                <span className="text-xl font-mono font-bold text-indigo-200">
                  {currentStep.productState}
                </span>
              </div>
              <div
                className={`px-2.5 py-1 rounded text-xs font-semibold flex items-center gap-1 ${
                  currentStep.productIsAccepting
                    ? 'bg-emerald-900/80 text-emerald-300 border border-emerald-600/60 shadow-sm'
                    : 'bg-rose-950/70 text-rose-300 border border-rose-800/60'
                }`}
              >
                {currentStep.productIsAccepting ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>UNION ACCEPT</span>
                  </>
                ) : (
                  <>
                    <XCircle className="w-3.5 h-3.5" />
                    <span>UNION REJECT</span>
                  </>
                )}
              </div>
            </div>

            {/* Boolean OR logic formula visualization */}
            <div className="mt-2.5 p-2 bg-slate-950/70 rounded border border-slate-800 font-mono text-[11px] text-slate-300">
              <div className="flex items-center justify-between">
                <span>q ∈ F₁:</span>
                <span className={currentStep.m1IsAccepting ? 'text-emerald-400 font-bold' : 'text-slate-500'}>
                  {currentStep.m1IsAccepting ? 'TRUE' : 'FALSE'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span>p ∈ F₂:</span>
                <span className={currentStep.m2IsAccepting ? 'text-emerald-400 font-bold' : 'text-slate-500'}>
                  {currentStep.m2IsAccepting ? 'TRUE' : 'FALSE'}
                </span>
              </div>
              <div className="flex items-center justify-between pt-1 mt-1 border-t border-slate-800 text-indigo-300 font-bold">
                <span>OR (Union):</span>
                <span>{currentStep.productIsAccepting ? 'TRUE (ACCEPT)' : 'FALSE (REJECT)'}</span>
              </div>
            </div>
          </div>

          <div className="mt-3 pt-2 border-t border-slate-800/70 text-[11px] text-indigo-400/80 font-mono">
            δ((q, p), a) = (δ₁(q, a), δ₂(p, a))
          </div>
        </div>
      </div>

      {/* Explanation Callout for Current Step */}
      <div className="p-3 bg-slate-900/90 border border-slate-800 rounded-lg flex items-start gap-2.5 text-xs">
        <Sparkles className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
        <div className="flex-1">
          <span className="font-semibold text-slate-200">Step Explanation: </span>
          <span className="text-slate-300 leading-relaxed">{currentStep.explanation}</span>
        </div>
      </div>

      {/* Final Verdict Banner (when at the end of input) */}
      {isAtEnd && (
        <div
          className={`p-4 rounded-lg border flex flex-col sm:flex-row items-center justify-between gap-3 ${
            simResult.unionAccepted
              ? 'bg-emerald-950/40 border-emerald-700 text-emerald-200'
              : 'bg-rose-950/40 border-rose-800 text-rose-200'
          }`}
        >
          <div className="flex items-center gap-3">
            {simResult.unionAccepted ? (
              <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
            ) : (
              <XCircle className="w-6 h-6 text-rose-400 shrink-0" />
            )}
            <div>
              <div className="font-semibold text-sm">
                String "{inputString === '' ? 'ε' : inputString}" is{' '}
                {simResult.unionAccepted ? 'ACCEPTED' : 'REJECTED'} by the Union DFA M
              </div>
              <div className="text-xs text-slate-300 opacity-90 mt-0.5">
                M₁: {simResult.m1Accepted ? 'Accepted' : 'Rejected'} · M₂:{' '}
                {simResult.m2Accepted ? 'Accepted' : 'Rejected'} · Product ends in state{' '}
                <span className="font-mono font-bold">{simResult.finalProductState}</span>
              </div>
            </div>
          </div>

          <div className="font-mono text-xs px-3 py-1.5 rounded bg-slate-900/80 border border-slate-800 text-slate-200">
            L(M₁) ∪ L(M₂) = {simResult.unionAccepted ? 'True' : 'False'}
          </div>
        </div>
      )}

      {/* Complete Step Trace History Log Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <div className="px-4 py-2.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between text-xs">
          <span className="font-semibold text-slate-200">Execution Trace Table</span>
          <span className="text-slate-500 font-mono">{simResult.steps.length} Steps</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950/70 text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-2 px-3">Step</th>
                <th className="py-2 px-3">Read Symbol</th>
                <th className="py-2 px-3">M₁ State</th>
                <th className="py-2 px-3">M₂ State</th>
                <th className="py-2 px-3">Product State</th>
                <th className="py-2 px-3">M₁ ∈ F₁</th>
                <th className="py-2 px-3">M₂ ∈ F₂</th>
                <th className="py-2 px-3">Union (OR)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {simResult.steps.map((st, idx) => {
                const isSelected = idx === currentStepIndex;
                return (
                  <tr
                    key={idx}
                    onClick={() => {
                      setIsPlaying(false);
                      setCurrentStepIndex(idx);
                    }}
                    className={`cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-indigo-950/70 font-semibold text-white'
                        : 'hover:bg-slate-800/50'
                    }`}
                  >
                    <td className="py-2 px-3">#{st.stepIndex}</td>
                    <td className="py-2 px-3">
                      {st.symbol === null ? (
                        <span className="text-slate-500">ε (start)</span>
                      ) : (
                        <span className="font-bold text-amber-300">'{st.symbol}'</span>
                      )}
                    </td>
                    <td className="py-2 px-3 text-cyan-400">{st.m1State}</td>
                    <td className="py-2 px-3 text-amber-400">{st.m2State}</td>
                    <td className="py-2 px-3 text-indigo-300 font-bold">{st.productState}</td>
                    <td className="py-2 px-3">
                      {st.m1IsAccepting ? (
                        <span className="text-emerald-400">T</span>
                      ) : (
                        <span className="text-slate-500">F</span>
                      )}
                    </td>
                    <td className="py-2 px-3">
                      {st.m2IsAccepting ? (
                        <span className="text-emerald-400">T</span>
                      ) : (
                        <span className="text-slate-500">F</span>
                      )}
                    </td>
                    <td className="py-2 px-3">
                      {st.productIsAccepting ? (
                        <span className="text-emerald-400 font-bold">ACCEPT</span>
                      ) : (
                        <span className="text-rose-400">REJECT</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
