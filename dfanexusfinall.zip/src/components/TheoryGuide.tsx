import React, { useState } from 'react';
import { DFA, ProductDFA } from '../types/automata';
import { BookOpen, HelpCircle, ChevronDown, ChevronRight, Award, Copy, Check } from 'lucide-react';

interface TheoryGuideProps {
  m1: DFA;
  m2: DFA;
  productDfa: ProductDFA;
}

export const TheoryGuide: React.FC<TheoryGuideProps> = ({ m1, m2, productDfa }) => {
  const [activeTab, setActiveTab] = useState<'tuples' | 'proof' | 'viva' | 'closure'>('tuples');
  const [expandedViva, setExpandedViva] = useState<number | null>(0);
  const [copiedMath, setCopiedMath] = useState(false);

  const vivaQuestions = [
    {
      q: 'What is the Cross-Product Construction in Automata Theory?',
      a: 'The cross-product construction (or Cartesian product automaton) is an algorithmic method to build a single deterministic finite automaton (DFA) that simultaneously simulates the parallel execution of two DFAs, M₁ and M₂, on the same input word. The state space is Q = Q₁ × Q₂, and every transition advances both state components in unison: δ((q, p), a) = (δ₁(q, a), δ₂(p, a)).',
    },
    {
      q: 'Why construct a product DFA instead of using an NFA with ε-transitions for Union?',
      a: 'While Thompson’s NFA construction for union is simple (creating a new start state with ε-transitions to q₀₁ and q₀₂), the resulting automaton is non-deterministic. If determinism is required—such as for hardware realization, O(1) per-symbol execution without backtracking, or subsequent complementation—the product DFA is already strictly deterministic and avoids the exponential worst-case subset construction step.',
    },
    {
      q: 'What is the maximum number of states in the product DFA?',
      a: 'The theoretical maximum number of states is |Q₁| × |Q₂|. For example, if M₁ has 3 states and M₂ has 4 states, the Cartesian product has at most 12 states. In practice, many of these states may be unreachable from the initial state (q₀₁, q₀₂) and can be pruned by reachability analysis (BFS/DFS).',
    },
    {
      q: 'Why do unreachable states emerge during the cross-product construction?',
      a: 'Unreachable states occur when certain state combinations cannot be triggered simultaneously by any valid input sequence. For example, if M₁ only reaches state q_acc when reading symbol "a" as the first letter, but M₂ only reaches state p_trap when reading "b" as the first letter, the state pair (q_acc, p_trap) can never be reached simultaneously on any input string.',
    },
    {
      q: 'How does the acceptance condition differ for Union, Intersection, and Set Difference?',
      a: 'The state space Q and transition function δ are identical for all boolean operations! Only the set of final states F differs: \n• Union (L₁ ∪ L₂): F = { (q, p) | q ∈ F₁ ∨ p ∈ F₂ }\n• Intersection (L₁ ∩ L₂): F = { (q, p) | q ∈ F₁ ∧ p ∈ F₂ }\n• Set Difference (L₁ \\ L₂): F = { (q, p) | q ∈ F₁ ∧ p ∉ F₂ }\n• Symmetric Difference (L₁ ⊕ L₂): F = { (q, p) | (q ∈ F₁ ∧ p ∉ F₂) ∨ (q ∉ F₁ ∧ p ∈ F₂) }',
    },
    {
      q: 'Is the product DFA always minimal?',
      a: 'No! The Cartesian product DFA is not guaranteed to be minimal. Even after removing unreachable states, some states may be equivalent (indistinguishable under the Myhill-Nerode theorem). Running Hopcroft’s DFA minimization algorithm or the Table-Filling algorithm on the product DFA produces the canonical minimal DFA.',
    },
    {
      q: 'What is the time complexity to construct the product DFA?',
      a: 'Computing the reachable states and transitions takes O(|Q₁| · |Q₂| · |Σ|) time using a Breadth-First Search (BFS) or Depth-First Search (DFS) starting from (q₀₁, q₀₂). Each reachable state is visited once, and |Σ| outgoing transitions are evaluated.',
    },
    {
      q: 'How does this prove that regular languages are closed under union?',
      a: 'Since L₁ and L₂ are regular languages, by definition there exist DFAs M₁ and M₂ such that L(M₁) = L₁ and L(M₂) = L₂. By applying the cross-product construction, we explicitly build a new 5-tuple M = (Q₁ × Q₂, Σ, δ, (q₀₁, q₀₂), F) and prove that L(M) = L₁ ∪ L₂. Because M is a valid DFA, the union language is also regular. Therefore, regular languages are closed under union.',
    },
  ];

  const handleCopyLaTeX = () => {
    const mathCode = `M_1 = (Q_1, \\Sigma, \\delta_1, q_{01}, F_1) \\\\
M_2 = (Q_2, \\Sigma, \\delta_2, q_{02}, F_2) \\\\
M = (Q_1 \\times Q_2, \\Sigma, \\delta, (q_{01}, q_{02}), F) \\\\
\\delta((q, p), a) = (\\delta_1(q, a), \\delta_2(p, a)) \\\\
F_{union} = \\{ (q, p) \\in Q_1 \\times Q_2 \\mid q \\in F_1 \\lor p \\in F_2 \\}`;
    navigator.clipboard.writeText(mathCode);
    setCopiedMath(true);
    setTimeout(() => setCopiedMath(false), 2000);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden flex flex-col text-xs">
      {/* Tab Navigation */}
      <div className="px-4 py-2.5 bg-slate-950 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1">
          {[
            { id: 'tuples', label: '5-Tuple Formalism' },
            { id: 'proof', label: 'Mathematical Proof' },
            { id: 'closure', label: 'Closure Properties' },
            { id: 'viva', label: 'Viva & Exam Questions' },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-1.5 rounded font-medium transition-colors ${
                activeTab === tab.id
                  ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={handleCopyLaTeX}
          className="flex items-center gap-1.5 px-2.5 py-1 text-slate-300 bg-slate-800 hover:bg-slate-700 rounded border border-slate-700 transition-colors"
        >
          {copiedMath ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span>Copied Math</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Copy LaTeX</span>
            </>
          )}
        </button>
      </div>

      {/* Tab Content */}
      <div className="p-4 flex flex-col gap-4">
        {activeTab === 'tuples' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Tuple M1 */}
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-3.5 flex flex-col gap-2">
              <span className="font-semibold text-cyan-400 text-sm">DFA M₁ 5-Tuple</span>
              <p className="text-slate-400 text-[11px] font-mono">M₁ = (Q₁, Σ, δ₁, q₀₁, F₁)</p>
              <div className="space-y-1.5 font-mono text-[11px] text-slate-300 mt-1">
                <div>Q₁ = {'{' + m1.states.join(', ') + '}'}</div>
                <div>Σ = {'{' + m1.alphabet.join(', ') + '}'}</div>
                <div>q₀₁ = {m1.initialState}</div>
                <div>F₁ = {'{' + m1.finalStates.join(', ') + '}'}</div>
                <div>Transitions: {Object.keys(m1.transitions).length * m1.alphabet.length} mappings</div>
              </div>
            </div>

            {/* Tuple M2 */}
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-3.5 flex flex-col gap-2">
              <span className="font-semibold text-amber-400 text-sm">DFA M₂ 5-Tuple</span>
              <p className="text-slate-400 text-[11px] font-mono">M₂ = (Q₂, Σ, δ₂, q₀₂, F₂)</p>
              <div className="space-y-1.5 font-mono text-[11px] text-slate-300 mt-1">
                <div>Q₂ = {'{' + m2.states.join(', ') + '}'}</div>
                <div>Σ = {'{' + m2.alphabet.join(', ') + '}'}</div>
                <div>q₀₂ = {m2.initialState}</div>
                <div>F₂ = {'{' + m2.finalStates.join(', ') + '}'}</div>
                <div>Transitions: {Object.keys(m2.transitions).length * m2.alphabet.length} mappings</div>
              </div>
            </div>

            {/* Tuple Product M */}
            <div className="bg-slate-950 border border-indigo-900/60 rounded-lg p-3.5 flex flex-col gap-2">
              <span className="font-semibold text-indigo-400 text-sm">Union DFA M 5-Tuple</span>
              <p className="text-slate-400 text-[11px] font-mono">M = (Q, Σ, δ, q₀, F)</p>
              <div className="space-y-1.5 font-mono text-[11px] text-slate-300 mt-1">
                <div>Q = Q₁ × Q₂ ({productDfa.states.length} active / {productDfa.allCartesianStatesCount} total)</div>
                <div>Σ = {'{' + productDfa.alphabet.join(', ') + '}'}</div>
                <div>q₀ = {productDfa.initialState}</div>
                <div>F = {'{' + productDfa.finalStates.join(', ') + '}'} ({productDfa.finalStates.length} states)</div>
                <div className="text-indigo-300">
                  δ((q, p), a) = (δ₁(q, a), δ₂(p, a))
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'proof' && (
          <div className="space-y-3 text-slate-300 leading-relaxed">
            <h4 className="font-semibold text-slate-100 text-sm">
              Theorem: Regular Languages are Closed Under Union via Product Construction
            </h4>
            <div className="bg-slate-950 border border-slate-800 rounded p-3 font-mono text-xs space-y-2">
              <div className="text-indigo-300 font-bold">Extended Transition Function δ̂ Induction:</div>
              <div>Base Case (|w| = 0, w = ε):</div>
              <div className="pl-4 text-slate-400">
                δ̂((q₀₁, q₀₂), ε) = (q₀₁, q₀₂) = (δ̂₁(q₀₁, ε), δ̂₂(q₀₂, ε))
              </div>
              <div>Induction Step: Suppose for string w, δ̂((q₀₁, q₀₂), w) = (δ̂₁(q₀₁, w), δ̂₂(q₀₂, w)).</div>
              <div>For string wa with symbol a ∈ Σ:</div>
              <div className="pl-4 text-slate-400">
                δ̂((q₀₁, q₀₂), wa) = δ(δ̂((q₀₁, q₀₂), w), a) = δ((q, p), a) = (δ₁(q, a), δ₂(p, a))
              </div>
              <div className="text-emerald-400 font-bold mt-2">Acceptance Equivalence:</div>
              <div className="pl-4 text-slate-300">
                w ∈ L(M) ⟺ δ̂((q₀₁, q₀₂), w) ∈ F
                <br />
                ⟺ (q, p) ∈ F
                <br />
                ⟺ (q ∈ F₁ ∨ p ∈ F₂)
                <br />
                ⟺ w ∈ L(M₁) ∨ w ∈ L(M₂)
                <br />
                ⟺ w ∈ L(M₁) ∪ L(M₂)
              </div>
            </div>
          </div>
        )}

        {activeTab === 'closure' && (
          <div className="space-y-3 text-slate-300">
            <h4 className="font-semibold text-slate-100 text-sm">
              Universal Boolean Closure of Regular Languages
            </h4>
            <p className="leading-relaxed">
              Because the Cartesian product state space Q = Q₁ × Q₂ tracks the exact internal state
              of both machines concurrently, all standard Boolean set operations can be computed
              over the exact same transition structure, merely by altering the acceptance criterion:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-2">
              <div className="p-3 bg-slate-950 border border-slate-800 rounded">
                <span className="font-semibold text-indigo-400 block font-mono">1. Union (L₁ ∪ L₂)</span>
                <span className="font-mono text-slate-300 text-[11px]">F = {'{ (q, p) | q ∈ F₁ ∨ p ∈ F₂ }'}</span>
                <p className="text-slate-400 mt-1 text-[11px]">
                  Accepts if either machine accepts the string.
                </p>
              </div>
              <div className="p-3 bg-slate-950 border border-slate-800 rounded">
                <span className="font-semibold text-indigo-400 block font-mono">2. Intersection (L₁ ∩ L₂)</span>
                <span className="font-mono text-slate-300 text-[11px]">F = {'{ (q, p) | q ∈ F₁ ∧ p ∈ F₂ }'}</span>
                <p className="text-slate-400 mt-1 text-[11px]">
                  Accepts only if both machines accept the string simultaneously.
                </p>
              </div>
              <div className="p-3 bg-slate-950 border border-slate-800 rounded">
                <span className="font-semibold text-indigo-400 block font-mono">3. Difference (L₁ \ L₂)</span>
                <span className="font-mono text-slate-300 text-[11px]">F = {'{ (q, p) | q ∈ F₁ ∧ p ∉ F₂ }'}</span>
                <p className="text-slate-400 mt-1 text-[11px]">
                  Accepts strings in L₁ that are NOT in L₂ (equivalent to L₁ ∩ L₂ᶜ).
                </p>
              </div>
              <div className="p-3 bg-slate-950 border border-slate-800 rounded">
                <span className="font-semibold text-indigo-400 block font-mono">4. Symmetric Difference (L₁ ⊕ L₂)</span>
                <span className="font-mono text-slate-300 text-[11px]">F = {'{ (q, p) | q ∈ F₁ ⊕ p ∈ F₂ }'}</span>
                <p className="text-slate-400 mt-1 text-[11px]">
                  Accepts strings accepted by exactly one of the two machines, but not both.
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'viva' && (
          <div className="space-y-2.5">
            {vivaQuestions.map((item, idx) => {
              const isExpanded = expandedViva === idx;
              return (
                <div
                  key={idx}
                  className="bg-slate-950 border border-slate-800/80 rounded overflow-hidden"
                >
                  <button
                    type="button"
                    onClick={() => setExpandedViva(isExpanded ? null : idx)}
                    className="w-full p-3 flex items-center justify-between text-left hover:bg-slate-900/60 transition-colors"
                  >
                    <span className="font-semibold text-slate-200">
                      Q{idx + 1}: {item.q}
                    </span>
                    {isExpanded ? (
                      <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
                    )}
                  </button>
                  {isExpanded && (
                    <div className="p-3 pt-0 border-t border-slate-800/60 text-slate-300 leading-relaxed whitespace-pre-line text-[11px]">
                      {item.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
