import React, { useMemo, useState } from 'react';
import { ArrowRightLeft, ChevronDown, Dices, Search, Shuffle, Sparkles } from 'lucide-react';
import { AlphabetType, DFALanguagePreset } from '../types/automata';

type AlphabetFilter = 'all' | AlphabetType;

type LanguagePairSelectorProps = {
  library: DFALanguagePreset[];
  selectedM1Id: string;
  selectedM2Id: string;
  alphabetFilter: AlphabetFilter;
  onAlphabetFilterChange: (filter: AlphabetFilter) => void;
  onSelectM1: (id: string) => void;
  onSelectM2: (id: string) => void;
  onRandomPair: () => void;
  onSwap: () => void;
};

function alphabetLabel(type: AlphabetType) {
  return type === 'binary' ? 'Binary {0,1}' : type === 'decimal' ? 'Decimal {0–9}' : 'Custom symbols';
}

function LanguagePicker({
  label,
  dfa,
  library,
  alphabetFilter,
  onSelect,
}: {
  label: string;
  dfa: DFALanguagePreset;
  library: DFALanguagePreset[];
  alphabetFilter: AlphabetFilter;
  onSelect: (id: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All');
  const compatible = alphabetFilter === 'all' || dfa.alphabetType === alphabetFilter;
  const scopedLibrary = useMemo(() => library.filter((item) => alphabetFilter === 'all' || item.alphabetType === alphabetFilter), [library, alphabetFilter]);
  const categories = useMemo(() => ['All', ...Array.from(new Set(scopedLibrary.map((item) => item.category))).sort()], [scopedLibrary]);
  const results = useMemo(() => scopedLibrary.filter((item) => {
    const matchesCategory = category === 'All' || item.category === category;
    const needle = query.trim().toLowerCase();
    return matchesCategory && (!needle || `${item.name} ${item.category} ${item.languageDescription}`.toLowerCase().includes(needle));
  }).slice(0, 80), [scopedLibrary, category, query]);

  return (
    <div className={`language-picker ${open ? 'is-open' : ''}`}>
      <div className="language-picker-label"><span>{label}</span><small>{compatible ? alphabetLabel(dfa.alphabetType) : 'Choose a compatible alphabet'}</small></div>
      <button type="button" className="language-picker-trigger" onClick={() => setOpen((value) => !value)} aria-expanded={open} aria-haspopup="listbox">
        <span className="language-picker-dot" />
        <span className="language-picker-current"><strong>{dfa.name}</strong><small>{dfa.languageDescription}</small></span>
        <ChevronDown size={16} />
      </button>
      {open && <div className="language-picker-popover" role="dialog" aria-label={`${label} selector`}>
        <div className="language-search"><Search size={14} /><input autoFocus value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search DFA language..." /></div>
        <div className="language-category-row" aria-label="Category filter">
          {categories.map((item) => <button type="button" key={item} className={category === item ? 'language-category active' : 'language-category'} onClick={() => setCategory(item)}>{item}</button>)}
        </div>
        <div className="language-results" role="listbox">
          {results.length === 0 && <p className="language-empty">No DFA languages match this search.</p>}
          {results.map((item) => <button type="button" role="option" aria-selected={item.id === dfa.id} key={item.id} className={item.id === dfa.id ? 'language-option active' : 'language-option'} onClick={() => { onSelect(item.id); setOpen(false); }}>
            <span className="language-option-main"><strong>{item.name}</strong><small>{item.languageDescription}</small></span>
            <span className="language-option-meta"><b>{alphabetLabel(item.alphabetType)}</b><em>{item.category}</em></span>
          </button>)}
        </div>
      </div>}
    </div>
  );
}

function LanguageInfo({ label, dfa }: { label: string; dfa: DFALanguagePreset }) {
  return <div className="language-info-card"><div className="language-info-heading"><span className="language-info-label">{label}</span><span className="language-info-alphabet">{alphabetLabel(dfa.alphabetType)}</span></div><strong>{dfa.name}</strong><p>{dfa.languageDescription}</p><div className="language-info-stats"><span>{dfa.states.length} states</span><span>{dfa.finalStates.length} accepting</span><span>ε {dfa.finalStates.includes(dfa.initialState) ? 'accepted' : 'rejected'}</span></div></div>;
}

export const LanguagePairSelector: React.FC<LanguagePairSelectorProps> = ({ library, selectedM1Id, selectedM2Id, alphabetFilter, onAlphabetFilterChange, onSelectM1, onSelectM2, onRandomPair, onSwap }) => {
  const selectedM1 = library.find((item) => item.id === selectedM1Id) ?? library[0];
  const selectedM2 = library.find((item) => item.id === selectedM2Id) ?? library[1] ?? library[0];
  if (!selectedM1 || !selectedM2) return null;
  return <div className="language-pair-selector">
    <div className="language-library-toolbar">
      <div><span className="control-label"><Sparkles size={13} /> Language library</span><p>Choose any two individual DFAs from the reusable TOC catalog.</p></div>
      <div className="alphabet-filter" role="radiogroup" aria-label="Alphabet filter">
        {(['all', 'binary', 'decimal'] as AlphabetFilter[]).map((filter) => <button type="button" key={filter} className={alphabetFilter === filter ? 'alphabet-filter-pill active' : 'alphabet-filter-pill'} onClick={() => onAlphabetFilterChange(filter)} role="radio" aria-checked={alphabetFilter === filter}>{filter === 'all' ? 'All' : filter === 'binary' ? 'Binary' : 'Decimal'}</button>)}
      </div>
    </div>
    <div className="language-pair-grid">
      <LanguagePicker label="Language 1 · M₁" dfa={selectedM1} library={library} alphabetFilter={alphabetFilter} onSelect={onSelectM1} />
      <div className="language-pair-connector" aria-hidden="true"><span>×</span><i /></div>
      <LanguagePicker label="Language 2 · M₂" dfa={selectedM2} library={library} alphabetFilter={alphabetFilter} onSelect={onSelectM2} />
    </div>
    <div className="language-pair-actions"><button type="button" className="secondary-action" onClick={onRandomPair}><Dices size={14} /> Random compatible pair</button><button type="button" className="secondary-action" onClick={onSwap}><ArrowRightLeft size={14} /> Swap M₁ ↔ M₂</button><span className="library-count"><Shuffle size={12} /> {library.length} languages indexed</span></div>
    <div className="language-info-grid"><LanguageInfo label="M₁" dfa={selectedM1} /><LanguageInfo label="M₂" dfa={selectedM2} /></div>
  </div>;
};
