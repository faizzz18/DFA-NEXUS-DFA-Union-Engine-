import React from 'react';

interface SplashScreenProps {
  visible: boolean;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ visible }) => {
  return (
    <div className={visible ? 'splash-screen' : 'splash-screen is-hidden'} role="status" aria-live="polite" aria-label="Loading DFA Nexus">
      <div className="splash-orbit splash-orbit-one" />
      <div className="splash-orbit splash-orbit-two" />
      <div className="splash-content">
        <img className="splash-logo" src="/dfa-nexus-logo.svg" alt="" />
        <div className="splash-wordmark"><strong>DFA Nexus</strong><span>Automata lab</span></div>
        <div className="splash-loading"><span /><span /><span /></div>
        <p>Mapping states into one decision</p>
      </div>
    </div>
  );
};
