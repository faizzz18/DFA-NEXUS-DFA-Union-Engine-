import React, { useState } from 'react';
import { DFA } from '../types/automata';
import { validateDFA } from '../utils/automataEngine';
import { Plus, Trash2, AlertTriangle, CheckCircle, Info } from 'lucide-react';

interface DFAEditorProps {
  dfa: DFA;
  onChange: (updatedDfa: DFA) => void;
  accentColor?: 'cyan' | 'amber';
}

export const DFAEditor: React.FC<DFAEditorProps> = ({
  dfa,
  onChange,
  accentColor = 'cyan',
}) => {
  const [newStateName, setNewStateName] = useState('');
  const [newSymbol, setNewSymbol] = useState('');

  const validation = validateDFA(dfa);

  const accentBorder = accentColor === 'cyan' ? 'border-cyan-500/40' : 'border-amber-500/40';
  const accentText = accentColor === 'cyan' ? 'text-cyan-400' : 'text-amber-400';
  const accentButton =
    accentColor === 'cyan'
      ? 'bg-cyan-700 hover:bg-cyan-600 text-white'
      : 'bg-amber-700 hover:bg-amber-600 text-white';

  // State operations
  const handleAddState = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newStateName.trim();
    if (!trimmed || dfa.states.includes(trimmed)) return;

    const updatedStates = [...dfa.states, trimmed];
    const updatedTransitions: Record<string, Record<string, string>> = { ...dfa.transitions, [trimmed]: {} };

    // Fill default self-loops for each symbol
    dfa.alphabet.forEach((sym) => {
      updatedTransitions[trimmed][sym] = trimmed;
    });

    onChange({
      ...dfa,
      states: updatedStates,
      transitions: updatedTransitions,
    });
    setNewStateName('');
  };

  const handleRemoveState = (stateToRemove: string) => {
    if (dfa.states.length <= 1) return; // keep at least 1 state
    const updatedStates = dfa.states.filter((s) => s !== stateToRemove);
    const updatedFinalStates = dfa.finalStates.filter((s) => s !== stateToRemove);
    const updatedInitialState =
      dfa.initialState === stateToRemove ? updatedStates[0] : dfa.initialState;

    const updatedTransitions: Record<string, Record<string, string>> = {};
    for (const q of updatedStates) {
      updatedTransitions[q] = {};
      for (const a of dfa.alphabet) {
        const next = dfa.transitions[q]?.[a];
        updatedTransitions[q][a] = next === stateToRemove ? updatedStates[0] : next ?? updatedStates[0];
      }
    }

    onChange({
      ...dfa,
      states: updatedStates,
      initialState: updatedInitialState,
      finalStates: updatedFinalStates,
      transitions: updatedTransitions,
    });
  };

  const handleToggleFinalState = (stateId: string) => {
    const isFinal = dfa.finalStates.includes(stateId);
    const updatedFinalStates = isFinal
      ? dfa.finalStates.filter((s) => s !== stateId)
      : [...dfa.finalStates, stateId];

    onChange({
      ...dfa,
      finalStates: updatedFinalStates,
    });
  };

  const handleSetInitialState = (stateId: string) => {
    onChange({
      ...dfa,
      initialState: stateId,
    });
  };

  const handleTransitionChange = (fromState: string, symbol: string, toState: string) => {
    const updatedTransitions = {
      ...dfa.transitions,
      [fromState]: {
        ...(dfa.transitions[fromState] || {}),
        [symbol]: toState,
      },
    };

    onChange({
      ...dfa,
      transitions: updatedTransitions,
    });
  };

  const handleAddSymbol = (e: React.FormEvent) => {
    e.preventDefault();
    const sym = newSymbol.trim();
    if (!sym || dfa.alphabet.includes(sym)) return;

    const updatedAlphabet = [...dfa.alphabet, sym];
    const updatedTransitions = { ...dfa.transitions };

    for (const q of dfa.states) {
      if (!updatedTransitions[q]) updatedTransitions[q] = {};
      updatedTransitions[q][sym] = q; // default self-loop
    }

    onChange({
      ...dfa,
      alphabet: updatedAlphabet,
      transitions: updatedTransitions,
    });
    setNewSymbol('');
  };

  const handleAddRecommendedDeadState = () => {
    const deadName = accentColor === 'cyan' ? 'q_dead' : 'p_dead';
    if (dfa.states.includes(deadName)) return;

    const updatedStates = [...dfa.states, deadName];
    const updatedTransitions: Record<string, Record<string, string>> = { ...dfa.transitions, [deadName]: {} };

    // Dead state self-loops on all symbols
    for (const sym of dfa.alphabet) {
      updatedTransitions[deadName][sym] = deadName;
    }

    onChange({
      ...dfa,
      states: updatedStates,
      transitions: updatedTransitions,
    });
  };

  const handleAutoFillMissing = () => {
    const deadName = dfa.states.includes(accentColor === 'cyan' ? 'q_dead' : 'p_dead')
      ? accentColor === 'cyan'
        ? 'q_dead'
        : 'p_dead'
      : dfa.states[0];

    const updatedTransitions: Record<string, Record<string, string>> = {};
    for (const q of dfa.states) {
      updatedTransitions[q] = { ...(dfa.transitions[q] || {}) };
      for (const a of dfa.alphabet) {
        if (!updatedTransitions[q][a] || !dfa.states.includes(updatedTransitions[q][a])) {
          updatedTransitions[q][a] = deadName;
        }
      }
    }

    onChange({
      ...dfa,
      transitions: updatedTransitions,
    });
  };

  return (
    <div className={`bg-slate-900 border ${accentBorder} rounded-lg p-4 flex flex-col gap-4 text-xs`}>
      {/* Title & Description */}
      <div>
        <div className="flex items-center justify-between">
          <h4 className={`text-sm font-semibold ${accentText}`}>{dfa.name}</h4>
          <div className="flex items-center gap-1.5 font-mono text-[11px]">
            {validation.isValid ? (
              <span className="text-emerald-400 flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" /> Valid DFA
              </span>
            ) : (
              <span className="text-amber-400 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" /> Issues Detected
              </span>
            )}
          </div>
        </div>

        <input
          type="text"
          value={dfa.description}
          onChange={(e) => onChange({ ...dfa, description: e.target.value })}
          placeholder="Language description, e.g. L = { w | ... }"
          className="w-full mt-2 bg-slate-950 border border-slate-700/80 rounded px-2.5 py-1 text-slate-300 font-sans focus:outline-none focus:border-slate-500"
        />
      </div>

      {/* Validation Warnings/Errors if any */}
      {(!validation.isValid || validation.warnings.length > 0) && (
        <div className="p-2.5 rounded bg-slate-950 border border-amber-900/50 text-amber-300 flex flex-col gap-1">
          {validation.errors.map((err, i) => (
            <div key={`err-${i}`} className="flex items-center gap-1.5">
              <span className="font-bold text-rose-400">Error:</span> {err}
            </div>
          ))}
          {validation.warnings.map((warn, i) => (
            <div key={`warn-${i}`} className="flex items-center gap-1.5">
              <span className="font-bold text-amber-400">Warning:</span> {warn}
            </div>
          ))}
        </div>
      )}

      {/* States Configuration */}
      <div className="flex flex-col gap-2">
        <span className="font-semibold text-slate-300">States Q:</span>
        <div className="flex flex-wrap items-center gap-2">
          {dfa.states.map((st) => {
            const isInitial = st === dfa.initialState;
            const isFinal = dfa.finalStates.includes(st);

            return (
              <div
                key={st}
                className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-950 border border-slate-700 font-mono text-xs"
              >
                <span className="font-bold text-slate-200">{st}</span>
                <span className="text-slate-600">·</span>
                {/* Initial button */}
                <button
                  type="button"
                  onClick={() => handleSetInitialState(st)}
                  title={isInitial ? 'Initial State' : 'Set as Initial'}
                  className={`text-[10px] px-1 rounded transition-colors ${
                    isInitial
                      ? 'bg-indigo-900 text-indigo-200 font-semibold'
                      : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  {isInitial ? 'init' : 'make init'}
                </button>

                {/* Final checkbox */}
                <button
                  type="button"
                  onClick={() => handleToggleFinalState(st)}
                  title={isFinal ? 'Accepting State' : 'Set as Final'}
                  className={`text-[10px] px-1 rounded transition-colors ${
                    isFinal
                      ? 'bg-emerald-950 text-emerald-300 font-semibold border border-emerald-800'
                      : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  {isFinal ? 'F' : '+F'}
                </button>

                {/* Delete button */}
                {dfa.states.length > 1 && (
                  <button
                    type="button"
                    onClick={() => handleRemoveState(st)}
                    className="text-slate-500 hover:text-rose-400 ml-1"
                    title="Delete State"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                )}
              </div>
            );
          })}

          {/* Add State form */}
          <form onSubmit={handleAddState} className="flex items-center gap-1">
            <input
              type="text"
              placeholder="New state name"
              value={newStateName}
              onChange={(e) => setNewStateName(e.target.value)}
              className="w-24 bg-slate-950 border border-slate-700 rounded px-2 py-1 font-mono text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-slate-500"
            />
            <button
              type="submit"
              className="p-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700"
              title="Add State"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </div>

      {/* Alphabet Σ Configuration */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className="font-semibold text-slate-300">Alphabet Σ:</span>
        <div className="flex items-center gap-1.5 font-mono">
          {dfa.alphabet.map((sym) => (
            <span
              key={sym}
              className="px-2 py-0.5 bg-slate-950 border border-slate-700 rounded text-slate-200"
            >
              '{sym}'
            </span>
          ))}
        </div>
      </div>

      {/* Transition Matrix Editor Table */}
      <div className="flex flex-col gap-1.5">
        <div className="flex items-center justify-between">
          <span className="font-semibold text-slate-300">Transition Matrix δ:</span>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={handleAddRecommendedDeadState}
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-[11px] transition-colors"
              title="Add a standard absorbing trap/dead state with self-loops"
            >
              + Add Trap State
            </button>
            <button
              type="button"
              onClick={handleAutoFillMissing}
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-[11px] transition-colors"
              title="Auto-fill missing transition cells"
            >
              Auto-Fill Missing
            </button>
          </div>
        </div>
        <div className="overflow-x-auto border border-slate-800 rounded bg-slate-950">
          <table className="w-full text-left font-mono text-xs">
            <thead className="bg-slate-900 border-b border-slate-800 text-slate-400">
              <tr>
                <th className="py-1.5 px-2.5">Current State</th>
                {dfa.alphabet.map((a) => (
                  <th key={a} className="py-1.5 px-2.5">
                    Symbol '{a}'
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {dfa.states.map((st) => (
                <tr key={st} className="hover:bg-slate-900/40">
                  <td className="py-1.5 px-2.5 font-bold text-slate-300">
                    {st === dfa.initialState ? '→ ' : ''}
                    {dfa.finalStates.includes(st) ? '* ' : ''}
                    {st}
                  </td>
                  {dfa.alphabet.map((a) => {
                    const currentTarget = dfa.transitions[st]?.[a] ?? '';
                    return (
                      <td key={a} className="py-1.5 px-2.5">
                        <select
                          value={currentTarget}
                          onChange={(e) => handleTransitionChange(st, a, e.target.value)}
                          className="bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                        >
                          {dfa.states.map((target) => (
                            <option key={target} value={target}>
                              {target}
                            </option>
                          ))}
                        </select>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
