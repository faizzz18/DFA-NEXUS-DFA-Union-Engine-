import React, { useState, useEffect, useMemo, useRef } from 'react';
import { DFA } from '../types/automata';
import { computeGraphLayout, computeEdgesLayout, NodePosition } from '../utils/layoutEngine';
import { ZoomIn, ZoomOut, RotateCcw, Maximize2 } from 'lucide-react';

interface AutomataCanvasProps {
  dfa: DFA;
  activeState?: string;
  activeTransition?: { from: string; to: string; symbol: string };
  theme?: 'cyan' | 'amber' | 'indigo' | 'emerald';
  title?: string;
  subtitle?: string;
  height?: number;
}

export const AutomataCanvas: React.FC<AutomataCanvasProps> = ({
  dfa,
  activeState,
  activeTransition,
  theme = 'indigo',
  title,
  subtitle,
  height = 360,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [nodePositions, setNodePositions] = useState<Record<string, NodePosition>>({});
  const [draggingNode, setDraggingNode] = useState<string | null>(null);

  const canvasWidth = 640;
  const canvasHeight = Math.max(340, height);

  // Compute default layout whenever states or initial state changes
  useEffect(() => {
    const layout = computeGraphLayout(dfa.states, dfa.initialState, canvasWidth, canvasHeight);
    setNodePositions(layout);
    setSelectedNode(null);
  }, [dfa.states.join(','), dfa.initialState, dfa.id]);

  const edges = useMemo(() => {
    return computeEdgesLayout(dfa.transitions, nodePositions, 28);
  }, [dfa.transitions, nodePositions]);

  // Color theme mapping
  const colorScheme = useMemo(() => {
    switch (theme) {
      case 'cyan':
        return {
          nodeFill: '#0e2a38',
          nodeBorder: '#06b6d4',
          activeNodeFill: '#0891b2',
          activeNodeGlow: 'rgba(6, 182, 212, 0.45)',
          edgeStroke: '#38bdf8',
          edgeActive: '#67e8f9',
          startArrow: '#38bdf8',
          badgeText: 'text-cyan-400',
        };
      case 'amber':
        return {
          nodeFill: '#38250e',
          nodeBorder: '#f59e0b',
          activeNodeFill: '#d97706',
          activeNodeGlow: 'rgba(245, 158, 11, 0.45)',
          edgeStroke: '#fbbf24',
          edgeActive: '#fde047',
          startArrow: '#fbbf24',
          badgeText: 'text-amber-400',
        };
      case 'emerald':
        return {
          nodeFill: '#0e3820',
          nodeBorder: '#10b981',
          activeNodeFill: '#059669',
          activeNodeGlow: 'rgba(16, 185, 129, 0.45)',
          edgeStroke: '#34d399',
          edgeActive: '#6ee7b7',
          startArrow: '#34d399',
          badgeText: 'text-emerald-400',
        };
      case 'indigo':
      default:
        return {
          nodeFill: '#1e1e38',
          nodeBorder: '#6366f1',
          activeNodeFill: '#4f46e5',
          activeNodeGlow: 'rgba(99, 102, 241, 0.45)',
          edgeStroke: '#818cf8',
          edgeActive: '#a5b4fc',
          startArrow: '#818cf8',
          badgeText: 'text-indigo-400',
        };
    }
  }, [theme]);

  // Node Dragging Handlers
  const handleMouseDownNode = (stateId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDraggingNode(stateId);
    setSelectedNode(stateId);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (draggingNode && nodePositions[draggingNode]) {
      const rect = containerRef.current?.getBoundingClientRect();
      if (!rect) return;
      const clientX = e.clientX - rect.left;
      const clientY = e.clientY - rect.top;

      // Unproject zoom & pan
      const scaleX = canvasWidth / rect.width;
      const scaleY = canvasHeight / rect.height;
      const unprojectedX = (clientX * scaleX - pan.x) / zoom;
      const unprojectedY = (clientY * scaleY - pan.y) / zoom;

      setNodePositions((prev) => ({
        ...prev,
        [draggingNode]: {
          id: draggingNode,
          x: Math.max(35, Math.min(canvasWidth - 35, unprojectedX)),
          y: Math.max(35, Math.min(canvasHeight - 35, unprojectedY)),
        },
      }));
    } else if (isPanning) {
      setPan({
        x: e.clientX - panStart.x,
        y: e.clientY - panStart.y,
      });
    }
  };

  const handleMouseUp = () => {
    setDraggingNode(null);
    setIsPanning(false);
  };

  const startPanning = (e: React.MouseEvent) => {
    if (e.button === 0) {
      setIsPanning(true);
      setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
    }
  };

  const handleResetView = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
    const layout = computeGraphLayout(dfa.states, dfa.initialState, canvasWidth, canvasHeight);
    setNodePositions(layout);
  };

  return (
    <div className="relative flex flex-col w-full bg-slate-900 border border-slate-800 rounded-lg overflow-hidden select-none">
      {/* Header bar */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-slate-950/80 border-b border-slate-800 text-xs">
        <div className="flex items-center gap-2">
          <span className={`font-semibold ${colorScheme.badgeText}`}>{title || dfa.name}</span>
          {subtitle && (
            <>
              <span className="text-slate-600">·</span>
              <span className="text-slate-400 truncate max-w-[280px]">{subtitle}</span>
            </>
          )}
        </div>

        {/* View Controls */}
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setZoom((z) => Math.min(2.0, z + 0.15))}
            className="p-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
            title="Zoom In"
            aria-label="Zoom in"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setZoom((z) => Math.max(0.6, z - 0.15))}
            className="p-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
            title="Zoom Out"
            aria-label="Zoom out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={handleResetView}
            className="p-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
            title="Reset Graph Layout & Zoom"
            aria-label="Reset layout"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* SVG Canvas Stage */}
      <div
        ref={containerRef}
        onMouseDown={startPanning}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className="w-full relative overflow-hidden cursor-grab active:cursor-grabbing bg-slate-950/90"
        style={{ height: `${height}px` }}
      >
        <svg
          viewBox={`0 0 ${canvasWidth} ${canvasHeight}`}
          className="w-full h-full pointer-events-auto"
        >
          <defs>
            {/* Arrowhead marker for normal edges */}
            <marker
              id={`arrow-${theme}`}
              viewBox="0 0 10 10"
              refX="8"
              refY="5"
              markerWidth="6"
              markerHeight="6"
              orient="auto-start-reverse"
            >
              <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill={colorScheme.edgeStroke} />
            </marker>

            {/* Active transition arrowhead marker */}
            <marker
              id={`arrow-active-${theme}`}
              viewBox="0 0 10 10"
              refX="8"
              refY="5"
              markerWidth="7"
              markerHeight="7"
              orient="auto-start-reverse"
            >
              <path d="M 0 1 L 9 5 L 0 9 z" fill="#38bdf8" />
            </marker>

            {/* Grid dot background */}
            <pattern id="dot-grid" x="0" y="0" width="24" height="24" patternUnits="userSpaceOnUse">
              <circle cx="2" cy="2" r="0.8" fill="#334155" opacity="0.6" />
            </pattern>
          </defs>

          {/* Background grid */}
          <rect width={canvasWidth} height={canvasHeight} fill="url(#dot-grid)" />

          <g transform={`translate(${pan.x}, ${pan.y}) scale(${zoom})`}>
            {/* Edge lines */}
            {edges.map((edge, idx) => {
              const isTransitionActive =
                activeTransition &&
                activeTransition.from === edge.fromId &&
                activeTransition.to === edge.toId &&
                edge.symbols.includes(activeTransition.symbol);

              return (
                <g key={`edge-${edge.fromId}-${edge.toId}-${idx}`}>
                  <path
                    d={edge.pathD}
                    fill="none"
                    stroke={isTransitionActive ? '#38bdf8' : colorScheme.edgeStroke}
                    strokeWidth={isTransitionActive ? 2.8 : 1.5}
                    strokeOpacity={isTransitionActive ? 1 : 0.65}
                    markerEnd={`url(#${isTransitionActive ? `arrow-active-${theme}` : `arrow-${theme}`})`}
                    className="transition-all duration-150"
                  />
                  {/* Symbol Label Box */}
                  <g transform={`translate(${edge.labelX}, ${edge.labelY})`}>
                    <rect
                      x="-14"
                      y="-10"
                      width="28"
                      height="18"
                      rx="4"
                      fill="#0f172a"
                      stroke={isTransitionActive ? '#38bdf8' : '#334155'}
                      strokeWidth="1"
                    />
                    <text
                      x="0"
                      y="3"
                      textAnchor="middle"
                      className="text-[11px] font-mono font-medium fill-slate-200 select-none"
                    >
                      {edge.symbols.join(',')}
                    </text>
                  </g>
                </g>
              );
            })}

            {/* State Nodes */}
            {dfa.states.map((stateId) => {
              const pos = nodePositions[stateId];
              if (!pos) return null;

              const isInitial = stateId === dfa.initialState;
              const isAccepting = dfa.finalStates.includes(stateId);
              const isActive = stateId === activeState;
              const isSelected = stateId === selectedNode;

              const nodeRadius = 26;

              return (
                <g
                  key={`node-${stateId}`}
                  transform={`translate(${pos.x}, ${pos.y})`}
                  onMouseDown={(e) => handleMouseDownNode(stateId, e)}
                  className="cursor-pointer"
                >
                  {/* Initial state entry arrow */}
                  {isInitial && (
                    <g transform={`translate(${-nodeRadius - 26}, 0)`}>
                      <line
                        x1="0"
                        y1="0"
                        x2="22"
                        y2="0"
                        stroke={colorScheme.startArrow}
                        strokeWidth="2.2"
                        markerEnd={`url(#arrow-${theme})`}
                      />
                      <text
                        x="-2"
                        y="-6"
                        textAnchor="end"
                        className="text-[10px] font-mono fill-slate-400 select-none"
                      >
                        start
                      </text>
                    </g>
                  )}

                  {/* Pulsing ring if active during simulation */}
                  {isActive && (
                    <circle
                      cx="0"
                      cy="0"
                      r={nodeRadius + 7}
                      fill="none"
                      stroke={colorScheme.edgeActive}
                      strokeWidth="2.5"
                      opacity="0.8"
                      className="animate-pulse"
                    />
                  )}

                  {/* Outer circle */}
                  <circle
                    cx="0"
                    cy="0"
                    r={nodeRadius}
                    fill={isActive ? colorScheme.activeNodeFill : colorScheme.nodeFill}
                    stroke={
                      isActive
                        ? colorScheme.edgeActive
                        : isSelected
                        ? '#ffffff'
                        : colorScheme.nodeBorder
                    }
                    strokeWidth={isActive ? 2.5 : 1.8}
                    className="transition-colors duration-150 shadow-lg"
                  />

                  {/* Inner circle for final (accepting) states */}
                  {isAccepting && (
                    <circle
                      cx="0"
                      cy="0"
                      r={nodeRadius - 5}
                      fill="none"
                      stroke={isActive ? '#ffffff' : colorScheme.nodeBorder}
                      strokeWidth="1.6"
                    />
                  )}

                  {/* State Name Label */}
                  <text
                    cx="0"
                    cy="0"
                    textAnchor="middle"
                    dy="4"
                    className="text-[11px] font-mono font-semibold fill-slate-100 select-none pointer-events-none"
                  >
                    {stateId}
                  </text>
                </g>
              );
            })}
          </g>
        </svg>

        {/* Selected Node Details Mini Overlay */}
        {selectedNode && (
          <div className="absolute bottom-2 left-2 p-2 bg-slate-900/95 border border-slate-700/80 rounded-md text-[11px] shadow-xl backdrop-blur-sm z-10 flex flex-col gap-1 max-w-[260px]">
            <div className="flex items-center justify-between font-mono font-semibold text-slate-200">
              <span>State: {selectedNode}</span>
              <button
                type="button"
                onClick={() => setSelectedNode(null)}
                className="text-slate-500 hover:text-slate-300 ml-2"
                aria-label="Close state inspector"
              >
                ✕
              </button>
            </div>
            <div className="text-slate-400 flex flex-wrap gap-x-2">
              <span>{selectedNode === dfa.initialState ? 'Initial' : 'Non-initial'}</span>
              <span>·</span>
              <span>{dfa.finalStates.includes(selectedNode) ? 'Accepting (F)' : 'Non-accepting'}</span>
            </div>
            <div className="text-slate-300 font-mono text-[10px] border-t border-slate-800 pt-1 mt-0.5">
              {dfa.alphabet.map((a) => (
                <div key={a}>
                  δ({selectedNode}, {a}) → {dfa.transitions[selectedNode]?.[a] ?? 'undefined'}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Footer Info Ribbon */}
      <div className="px-3 py-1.5 bg-slate-950 text-[11px] text-slate-400 border-t border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span>|Q| = {dfa.states.length}</span>
          <span className="text-slate-700">|</span>
          <span>|Σ| = {dfa.alphabet.length} ({dfa.alphabet.join(', ')})</span>
          <span className="text-slate-700">|</span>
          <span>|F| = {dfa.finalStates.length}</span>
        </div>
        <span className="text-[10px] text-slate-500 hidden sm:inline">
          Drag nodes to rearrange
        </span>
      </div>
    </div>
  );
};
