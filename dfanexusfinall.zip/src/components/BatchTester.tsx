import React, { useState, useEffect } from 'react';
import { DFA, ProductDFA } from '../types/automata';
import { simulateParallel } from '../utils/automataEngine';
import { Plus, Trash2, CheckCircle2, XCircle, Sparkles, RotateCcw, Download } from 'lucide-react';

interface BatchTesterProps {
  m1: DFA;
  m2: DFA;
  productDfa: ProductDFA;
  initialStrings?: string[];
  recommendedStrings?: string[];
  onSelectStringForSimulation?: (str: string) => void;
}

export const BatchTester: React.FC<BatchTesterProps> = ({
  m1,
  m2,
  productDfa,
  initialStrings = ['', '0', '1', '00', '01', '10', '11', '001', '010', '111', '1010'],
  recommendedStrings = [],
  onSelectStringForSimulation,
}) => {
  const [testStrings, setTestStrings] = useState<string[]>(
    recommendedStrings.length > 0 ? recommendedStrings : initialStrings
  );
  const [newString, setNewString] = useState<string>('');
  const [filterMode, setFilterMode] = useState<'all' | 'accepted' | 'rejected'>('all');

  // When recommendedStrings changes (e.g., user selects a different preset)
  useEffect(() => {
    if (recommendedStrings && recommendedStrings.length > 0) {
      setTestStrings(recommendedStrings);
    }
  }, [recommendedStrings]);

  const results = React.useMemo(() => {
    return testStrings.map((str) => {
      const sim = simulateParallel(m1, m2, productDfa, str);
      return {
        str,
        m1Accepted: sim.m1Accepted,
        m2Accepted: sim.m2Accepted,
        unionAccepted: sim.unionAccepted,
        finalState: sim.finalProductState,
      };
    });
  }, [m1, m2, productDfa, testStrings]);

  const handleAddString = (e: React.FormEvent) => {
    e.preventDefault();
    if (!testStrings.includes(newString)) {
      setTestStrings([...testStrings, newString]);
      setNewString('');
    }
  };

  const handleRemove = (str: string) => {
    setTestStrings(testStrings.filter((s) => s !== str));
  };

  const handleAddAllRecommended = () => {
    if (!recommendedStrings || recommendedStrings.length === 0) return;
    const combined = Array.from(new Set([...testStrings, ...recommendedStrings]));
    setTestStrings(combined);
  };

  const handleResetToAllRecommended = () => {
    if (!recommendedStrings || recommendedStrings.length === 0) return;
    setTestStrings([...recommendedStrings]);
  };

  const acceptedCount = results.filter((r) => r.unionAccepted).length;
  const rejectedCount = results.length - acceptedCount;

  const filteredResults = results.filter((r) => {
    if (filterMode === 'accepted') return r.unionAccepted;
    if (filterMode === 'rejected') return !r.unionAccepted;
    return true;
  });

  const handleExportCSV = () => {
    const header = 'String,Length,M1_Result,M2_Result,Union_Result,Final_Product_State\n';
    const rows = results
      .map(
        (r) =>
          `"${r.str}",${r.str.length},${r.m1Accepted ? 'ACCEPT' : 'REJECT'},${
            r.m2Accepted ? 'ACCEPT' : 'REJECT'
          },${r.unionAccepted ? 'ACCEPT' : 'REJECT'},"${r.finalState}"`
      )
      .join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'batch_test_results.csv';
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden flex flex-col text-xs">
      {/* Header and Recommended Controls */}
      <div className="p-4 bg-slate-950 border-b border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h4 className="font-semibold text-slate-200 text-sm">Batch Test Suite</h4>
            <span className="text-slate-500 font-mono">({results.length} total tests)</span>
          </div>
          <p className="text-slate-400 text-xs mt-0.5">
            Evaluate comprehensive test cases simultaneously against M₁, M₂, and the Union DFA
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {recommendedStrings.length > 0 && (
            <>
              <button
                type="button"
                onClick={handleAddAllRecommended}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded font-medium transition-colors shadow-sm"
                title="Add all recommended test strings for this DFA preset"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Add All Recommended ({recommendedStrings.length})</span>
              </button>
              <button
                type="button"
                onClick={handleResetToAllRecommended}
                className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 transition-colors"
                title="Reset test suite to exactly the recommended preset strings"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset to Recommended</span>
              </button>
            </>
          )}

          <button
            type="button"
            onClick={handleExportCSV}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 transition-colors"
            title="Export CSV of test results"
          >
            <Download className="w-3 h-3" />
            <span>CSV</span>
          </button>
        </div>
      </div>

      {/* Filter and Add String Bar */}
      <div className="px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="text-slate-400">Filter:</span>
          <div className="flex items-center gap-1 bg-slate-950 p-0.5 rounded border border-slate-800">
            <button
              type="button"
              onClick={() => setFilterMode('all')}
              className={`px-2.5 py-1 rounded transition-colors ${
                filterMode === 'all'
                  ? 'bg-slate-800 text-white font-medium'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All ({results.length})
            </button>
            <button
              type="button"
              onClick={() => setFilterMode('accepted')}
              className={`px-2.5 py-1 rounded transition-colors ${
                filterMode === 'accepted'
                  ? 'bg-emerald-950 text-emerald-300 font-medium border border-emerald-800'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Accepted ({acceptedCount})
            </button>
            <button
              type="button"
              onClick={() => setFilterMode('rejected')}
              className={`px-2.5 py-1 rounded transition-colors ${
                filterMode === 'rejected'
                  ? 'bg-rose-950 text-rose-300 font-medium border border-rose-800'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Rejected ({rejectedCount})
            </button>
          </div>
        </div>

        {/* Add custom string form */}
        <form onSubmit={handleAddString} className="flex items-center gap-1">
          <input
            type="text"
            placeholder="Add custom string..."
            value={newString}
            onChange={(e) => setNewString(e.target.value)}
            className="bg-slate-950 border border-slate-700 rounded px-2.5 py-1 font-mono text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500 w-36"
          />
          <button
            type="submit"
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700"
            title="Add test string"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>

      {/* Table of Results */}
      <div className="overflow-x-auto">
        <table className="w-full text-left font-mono text-xs">
          <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
            <tr>
              <th className="py-2.5 px-3">Test String w</th>
              <th className="py-2.5 px-3">Length</th>
              <th className="py-2.5 px-3 text-cyan-400">M₁ Result</th>
              <th className="py-2.5 px-3 text-amber-400">M₂ Result</th>
              <th className="py-2.5 px-3 text-indigo-300">Union Result (M₁ ∪ M₂)</th>
              <th className="py-2.5 px-3">Final Product State</th>
              <th className="py-2.5 px-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-slate-300">
            {filteredResults.map((r, idx) => (
              <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                <td className="py-2 px-3 font-bold text-slate-100">
                  {r.str === '' ? <span className="text-slate-500 font-normal">ε (empty)</span> : r.str}
                </td>
                <td className="py-2 px-3 text-slate-400">{r.str.length}</td>
                <td className="py-2 px-3">
                  {r.m1Accepted ? (
                    <span className="text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Accept
                    </span>
                  ) : (
                    <span className="text-slate-500 flex items-center gap-1">
                      <XCircle className="w-3.5 h-3.5" /> Reject
                    </span>
                  )}
                </td>
                <td className="py-2 px-3">
                  {r.m2Accepted ? (
                    <span className="text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Accept
                    </span>
                  ) : (
                    <span className="text-slate-500 flex items-center gap-1">
                      <XCircle className="w-3.5 h-3.5" /> Reject
                    </span>
                  )}
                </td>
                <td className="py-2 px-3 font-semibold">
                  {r.unionAccepted ? (
                    <span className="text-emerald-300 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> UNION ACCEPT
                    </span>
                  ) : (
                    <span className="text-rose-400 flex items-center gap-1">
                      <XCircle className="w-3.5 h-3.5" /> UNION REJECT
                    </span>
                  )}
                </td>
                <td className="py-2 px-3 text-indigo-300">{r.finalState}</td>
                <td className="py-2 px-3 text-right">
                  <div className="flex items-center justify-end gap-2">
                    {onSelectStringForSimulation && (
                      <button
                        type="button"
                        onClick={() => onSelectStringForSimulation(r.str)}
                        className="px-2 py-0.5 rounded bg-indigo-950 hover:bg-indigo-900 text-indigo-300 border border-indigo-800 text-[11px] font-sans transition-colors"
                      >
                        Simulate
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleRemove(r.str)}
                      className="text-slate-500 hover:text-rose-400 p-1"
                      title="Remove test"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
