import React from 'react';
import { ArrowLeft, BookOpenText, Download, ListChecks, Menu, PencilRuler, Play, Table2, X } from 'lucide-react';

type WorkspaceView = 'simulation' | 'matrix' | 'batch' | 'editor' | 'theory';

interface TopNavProps {
  activeView: WorkspaceView;
  onSelectView: (view: WorkspaceView) => void;
  onOpenExport: () => void;
}

const menuGroups: Array<{ label: string; items: Array<{ id: WorkspaceView; label: string; description: string; icon: React.ElementType }> }> = [
  { label: 'Explore', items: [
    { id: 'simulation', label: 'Simulator', description: 'Trace one string across three machines.', icon: Play },
    { id: 'matrix', label: 'Transition table', description: 'Inspect the product DFA row by row.', icon: Table2 },
    { id: 'batch', label: 'Batch tests', description: 'Compare many strings at once.', icon: ListChecks },
  ] },
  { label: 'Build & learn', items: [
    { id: 'editor', label: 'DFA editor', description: 'Shape the languages you want to combine.', icon: PencilRuler },
    { id: 'theory', label: 'Theory guide', description: 'Connect the visual result to the proof.', icon: BookOpenText },
  ] },
];

export const TopNav: React.FC<TopNavProps> = ({ activeView, onSelectView, onOpenExport }) => {
  const [menuOpen, setMenuOpen] = React.useState(false);
  const handleBack = () => {
    if (activeView !== 'simulation') {
      onSelectView('simulation');
      return;
    }
    if (window.history.length > 1) window.history.back();
  };
  const selectFromMenu = (view: WorkspaceView) => {
    onSelectView(view);
    setMenuOpen(false);
  };
  const activeMenuItem = menuGroups.flatMap((group) => group.items).find((item) => item.id === activeView) ?? menuGroups[0].items[0];

  return (
    <header className="top-nav">
      <button type="button" className="back-action" onClick={handleBack} aria-label={activeView === 'simulation' ? 'Go back' : 'Back to simulator'} title={activeView === 'simulation' ? 'Go back' : 'Back to simulator'}><ArrowLeft size={16} /></button>
      <button type="button" className="brand-lockup" onClick={() => onSelectView('simulation')} aria-label="Open DFA Nexus simulator">
        <span className="brand-mark" aria-hidden="true"><img className="brand-image" src="/manus-storage/async-images/n6xbarvHAhZfpAN1Z4hZ1z/image-1.webp" alt="" onError={(event) => { event.currentTarget.onerror = null; event.currentTarget.src = '/dfa-nexus-logo.svg'; }} /></span>
        <span className="brand-copy"><strong>DFA Nexus</strong><small>AUTOMATA <span>·</span> LAB</small></span>
      </button>

      <div className="menu-cluster">
        <button type="button" className={menuOpen ? 'menu-toggle is-open' : 'menu-toggle'} onClick={() => setMenuOpen((open) => !open)} aria-expanded={menuOpen} aria-haspopup="menu"><span className="menu-toggle-icon">{menuOpen ? <X size={15} /> : <Menu size={15} />}</span><span className="menu-toggle-label">Menu</span><span className="menu-current">{activeMenuItem.label}</span></button>
        {menuOpen && <div className="menu-panel" role="menu" aria-label="DFA Nexus features">
          {menuGroups.map((group) => <div className="menu-group" key={group.label}>
            <span className="menu-group-label">{group.label}</span>
            {group.items.map((item) => { const Icon = item.icon; return <button key={item.id} type="button" role="menuitem" className={activeView === item.id ? 'menu-item active' : 'menu-item'} onClick={() => selectFromMenu(item.id)}><span className="menu-item-icon"><Icon size={15} /></span><span><strong>{item.label}</strong><small>{item.description}</small></span></button>; })}
          </div>)}
        </div>}
      </div>

      <div className="top-nav-actions">
        <span className="connection-pill"><span className="live-dot" /> Local model</span>
        <button type="button" className="export-action" onClick={onOpenExport}><Download size={15} /><span>Export</span></button>
      </div>
    </header>
  );
};
