import { DFA, OperationMode, ProductDFA, ProductStateMetadata, SimulationResult, SimulationStep } from '../types/automata';

/**
 * Format a state pair cleanly, e.g. "(q0, p1)"
 */
export function formatProductStateId(q1: string, q2: string): string {
  return `(${q1}, ${q2})`;
}

/**
 * Validate a DFA for completeness and structural correctness
 */
export function validateDFA(dfa: DFA): {
  isValid: boolean;
  errors: string[];
  warnings: string[];
} {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!dfa.states || dfa.states.length === 0) {
    errors.push('State set Q cannot be empty.');
  }

  if (!dfa.alphabet || dfa.alphabet.length === 0) {
    errors.push('Alphabet Σ cannot be empty.');
  }

  if (!dfa.initialState || !dfa.states.includes(dfa.initialState)) {
    errors.push(`Initial state "${dfa.initialState}" is not in the set of states Q.`);
  }

  for (const f of dfa.finalStates) {
    if (!dfa.states.includes(f)) {
      errors.push(`Final state "${f}" is not in the set of states Q.`);
    }
  }

  // Check transitions completeness
  for (const q of dfa.states) {
    const stateTransitions = dfa.transitions[q] || {};
    for (const a of dfa.alphabet) {
      const next = stateTransitions[a];
      if (next === undefined || next === '') {
        warnings.push(`Missing transition for state "${q}" on symbol "${a}".`);
      } else if (!dfa.states.includes(next)) {
        errors.push(`Invalid transition: δ("${q}", "${a}") = "${next}", but "${next}" is not in Q.`);
      }
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
  };
}

export function areAlphabetsCompatible(m1: DFA, m2: DFA): boolean {
  return m1.alphabet.length === m2.alphabet.length && m1.alphabet.every((symbol) => m2.alphabet.includes(symbol));
}

/**
 * Computes the Cross-Product DFA M = M1 ⨂ M2
 */
export function computeProductDFA(
  m1: DFA,
  m2: DFA,
  operationMode: OperationMode = 'union',
  reachableOnly: boolean = true
): ProductDFA {
  // Common alphabet: union of alphabets or intersection
  const alphabet = Array.from(new Set([...m1.alphabet, ...m2.alphabet])).sort();

  const productStatesMeta: Record<string, ProductStateMetadata> = {};
  const allCartesianPairs: { q1: string; q2: string; id: string }[] = [];

  for (const q1 of m1.states) {
    for (const q2 of m2.states) {
      const id = formatProductStateId(q1, q2);
      const isInitial = q1 === m1.initialState && q2 === m2.initialState;
      const isAcceptingM1 = m1.finalStates.includes(q1);
      const isAcceptingM2 = m2.finalStates.includes(q2);

      const isAcceptingUnion = isAcceptingM1 || isAcceptingM2;
      const isAcceptingIntersection = isAcceptingM1 && isAcceptingM2;
      const isAcceptingDifference = isAcceptingM1 && !isAcceptingM2;
      const isAcceptingSymDiff = (isAcceptingM1 && !isAcceptingM2) || (!isAcceptingM1 && isAcceptingM2);

      productStatesMeta[id] = {
        id,
        q1,
        q2,
        isInitial,
        isAcceptingM1,
        isAcceptingM2,
        isAcceptingUnion,
        isAcceptingIntersection,
        isAcceptingDifference,
        isAcceptingSymDiff,
        isReachable: false,
        depth: -1,
      };

      allCartesianPairs.push({ q1, q2, id });
    }
  }

  const initialProductState = formatProductStateId(m1.initialState, m2.initialState);

  // Compute full transition matrix
  const fullTransitions: Record<string, Record<string, string>> = {};
  for (const pair of allCartesianPairs) {
    fullTransitions[pair.id] = {};
    for (const a of alphabet) {
      const nextQ1 = m1.transitions[pair.q1]?.[a] ?? pair.q1;
      const nextQ2 = m2.transitions[pair.q2]?.[a] ?? pair.q2;
      fullTransitions[pair.id][a] = formatProductStateId(nextQ1, nextQ2);
    }
  }

  // BFS to determine Reachability and Depth from initial state
  const reachableSet = new Set<string>();
  const queue: { id: string; depth: number }[] = [];

  if (productStatesMeta[initialProductState]) {
    reachableSet.add(initialProductState);
    productStatesMeta[initialProductState].isReachable = true;
    productStatesMeta[initialProductState].depth = 0;
    queue.push({ id: initialProductState, depth: 0 });
  }

  while (queue.length > 0) {
    const { id: currId, depth } = queue.shift()!;
    const trans = fullTransitions[currId] || {};
    for (const a of alphabet) {
      const nextId = trans[a];
      if (nextId && !reachableSet.has(nextId) && productStatesMeta[nextId]) {
        reachableSet.add(nextId);
        productStatesMeta[nextId].isReachable = true;
        productStatesMeta[nextId].depth = depth + 1;
        queue.push({ id: nextId, depth: depth + 1 });
      }
    }
  }

  // Filter states based on reachableOnly flag
  const activeStateIds = reachableOnly
    ? allCartesianPairs.filter((p) => reachableSet.has(p.id)).map((p) => p.id)
    : allCartesianPairs.map((p) => p.id);

  // Determine final states based on operation mode
  const finalStates: string[] = [];
  for (const id of activeStateIds) {
    const meta = productStatesMeta[id];
    let isFinal = false;
    if (operationMode === 'union') {
      isFinal = meta.isAcceptingUnion;
    } else if (operationMode === 'intersection') {
      isFinal = meta.isAcceptingIntersection;
    } else if (operationMode === 'difference') {
      isFinal = meta.isAcceptingDifference;
    } else if (operationMode === 'symmetric_difference') {
      isFinal = meta.isAcceptingSymDiff;
    }
    if (isFinal) {
      finalStates.push(id);
    }
  }

  // Build pruned transition table
  const transitions: Record<string, Record<string, string>> = {};
  for (const id of activeStateIds) {
    transitions[id] = {};
    for (const a of alphabet) {
      const target = fullTransitions[id]?.[a];
      if (target) {
        transitions[id][a] = target;
      }
    }
  }

  let modeLabel = 'Union';
  if (operationMode === 'intersection') modeLabel = 'Intersection';
  else if (operationMode === 'difference') modeLabel = 'Difference (M₁ \\ M₂)';
  else if (operationMode === 'symmetric_difference') modeLabel = 'Symmetric Difference (M₁ ⊕ M₂)';

  return {
    id: `product_${operationMode}`,
    name: `${modeLabel} DFA M`,
    description: `Constructed via Cartesian cross-product Q₁ × Q₂ with ${modeLabel} acceptance condition`,
    states: activeStateIds,
    alphabet,
    initialState: initialProductState,
    finalStates,
    transitions,
    productStatesMeta,
    allCartesianStatesCount: allCartesianPairs.length,
    reachableStatesCount: reachableSet.size,
    operationMode,
  };
}

/**
 * Simulate an input string synchronously across M1, M2, and the Product DFA
 */
export function simulateParallel(
  m1: DFA,
  m2: DFA,
  productDfa: ProductDFA,
  inputString: string
): SimulationResult {
  const steps: SimulationStep[] = [];

  let currM1 = m1.initialState;
  let currM2 = m2.initialState;
  let currProduct = productDfa.initialState;

  // Step 0: Initial state before any input is read
  const m1InitAccepting = m1.finalStates.includes(currM1);
  const m2InitAccepting = m2.finalStates.includes(currM2);
  const productInitAccepting = isStateAcceptingForMode(
    productDfa.productStatesMeta[currProduct],
    productDfa.operationMode
  );

  steps.push({
    stepIndex: 0,
    symbol: null,
    remainingInput: inputString,
    consumedInput: '',
    m1State: currM1,
    m1IsAccepting: m1InitAccepting,
    m2State: currM2,
    m2IsAccepting: m2InitAccepting,
    productState: currProduct,
    productIsAccepting: productInitAccepting,
    explanation: `Initial state: M₁ is in ${currM1}, M₂ is in ${currM2}. Product DFA starts at ${currProduct}.`,
  });

  // Process each symbol
  for (let i = 0; i < inputString.length; i++) {
    const symbol = inputString[i];
    const consumed = inputString.slice(0, i + 1);
    const remaining = inputString.slice(i + 1);

    const nextM1 = m1.transitions[currM1]?.[symbol] ?? currM1;
    const nextM2 = m2.transitions[currM2]?.[symbol] ?? currM2;
    const nextProduct = productDfa.transitions[currProduct]?.[symbol] ?? formatProductStateId(nextM1, nextM2);

    const nextM1Accepting = m1.finalStates.includes(nextM1);
    const nextM2Accepting = m2.finalStates.includes(nextM2);
    const nextProductMeta = productDfa.productStatesMeta[nextProduct];
    const nextProductAccepting = nextProductMeta
      ? isStateAcceptingForMode(nextProductMeta, productDfa.operationMode)
      : nextM1Accepting || nextM2Accepting;

    // Build explanatory text
    let opLogicText = '';
    if (productDfa.operationMode === 'union') {
      opLogicText = `M₁ ∈ F₁ (${nextM1Accepting ? 'T' : 'F'}) ∨ M₂ ∈ F₂ (${nextM2Accepting ? 'T' : 'F'}) = ${nextProductAccepting ? 'True (Accepted)' : 'False (Rejected)'}`;
    } else if (productDfa.operationMode === 'intersection') {
      opLogicText = `M₁ ∈ F₁ (${nextM1Accepting ? 'T' : 'F'}) ∧ M₂ ∈ F₂ (${nextM2Accepting ? 'T' : 'F'}) = ${nextProductAccepting ? 'True (Accepted)' : 'False (Rejected)'}`;
    } else {
      opLogicText = `M₁ ∈ F₁: ${nextM1Accepting ? 'T' : 'F'}, M₂ ∈ F₂: ${nextM2Accepting ? 'T' : 'F'}`;
    }

    const explanation = `Read symbol '${symbol}': δ₁(${currM1}, '${symbol}') → ${nextM1}, δ₂(${currM2}, '${symbol}') → ${nextM2}. Parallel move: δ(${currProduct}, '${symbol}') → ${nextProduct}. Acceptance: ${opLogicText}.`;

    steps.push({
      stepIndex: i + 1,
      symbol,
      remainingInput: remaining,
      consumedInput: consumed,
      m1State: nextM1,
      m1IsAccepting: nextM1Accepting,
      m2State: nextM2,
      m2IsAccepting: nextM2Accepting,
      productState: nextProduct,
      productIsAccepting: nextProductAccepting,
      explanation,
    });

    currM1 = nextM1;
    currM2 = nextM2;
    currProduct = nextProduct;
  }

  const finalM1Accepted = m1.finalStates.includes(currM1);
  const finalM2Accepted = m2.finalStates.includes(currM2);
  const finalUnionAccepted = finalM1Accepted || finalM2Accepted;
  const finalMeta = productDfa.productStatesMeta[currProduct];
  const finalOperationAccepted = finalMeta
    ? isStateAcceptingForMode(finalMeta, productDfa.operationMode)
    : finalUnionAccepted;

  return {
    inputString,
    steps,
    m1Accepted: finalM1Accepted,
    m2Accepted: finalM2Accepted,
    unionAccepted: finalUnionAccepted,
    operationAccepted: finalOperationAccepted,
    finalProductState: currProduct,
  };
}

function isStateAcceptingForMode(meta: ProductStateMetadata | undefined, mode: OperationMode): boolean {
  if (!meta) return false;
  switch (mode) {
    case 'union':
      return meta.isAcceptingUnion;
    case 'intersection':
      return meta.isAcceptingIntersection;
    case 'difference':
      return meta.isAcceptingDifference;
    case 'symmetric_difference':
      return meta.isAcceptingSymDiff;
  }
}

/**
 * Generate LaTeX code for transition table
 */
export function generateLaTeXTransitionTable(dfa: DFA): string {
  const alphabetCols = dfa.alphabet.map(() => 'c').join(' | ');
  const headerSymbols = dfa.alphabet.map((a) => `$${a}$`).join(' & ');

  let rows = '';
  for (const q of dfa.states) {
    const isStart = q === dfa.initialState ? '\\rightarrow ' : '';
    const isFinal = dfa.finalStates.includes(q) ? '*' : '';
    const stateLabel = `$${isStart}${isFinal}${q}$`;
    const transCols = dfa.alphabet.map((a) => {
      const next = dfa.transitions[q]?.[a] ?? '-';
      return `$${next}$`;
    }).join(' & ');
    rows += `  ${stateLabel} & ${transCols} \\\\\n`;
  }

  return `% Transition Table for ${dfa.name}
\\begin{table}[h!]
\\centering
\\begin{tabular}{| r | ${alphabetCols} |}
\\hline
State & ${headerSymbols} \\\\
\\hline
${rows}\\hline
\\end{tabular}
\\caption{Transition Table for ${dfa.name}}
\\end{table}`;
}

/**
 * Generate CSV representation of transition table
 */
export function generateCSVTransitionTable(dfa: DFA): string {
  const headers = ['State', 'IsStart', 'IsFinal', ...dfa.alphabet];
  const lines: string[] = [headers.join(',')];

  for (const q of dfa.states) {
    const isStart = q === dfa.initialState ? 'YES' : 'NO';
    const isFinal = dfa.finalStates.includes(q) ? 'YES' : 'NO';
    const nextStates = dfa.alphabet.map((a) => dfa.transitions[q]?.[a] ?? '');
    lines.push([`"${q}"`, isStart, isFinal, ...nextStates.map((s) => `"${s}"`)].join(','));
  }

  return lines.join('\n');
}
