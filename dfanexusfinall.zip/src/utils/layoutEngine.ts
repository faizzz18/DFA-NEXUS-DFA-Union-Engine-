export interface NodePosition {
  id: string;
  x: number;
  y: number;
}

export interface EdgeLayout {
  fromId: string;
  toId: string;
  symbols: string[];
  pathD: string;
  labelX: number;
  labelY: number;
  isSelfLoop: boolean;
  isCurved: boolean;
}

/**
 * Computes coordinates for states within a given SVG viewBox
 */
export function computeGraphLayout(
  states: string[],
  initialState: string,
  width: number = 600,
  height: number = 400
): Record<string, NodePosition> {
  const positions: Record<string, NodePosition> = {};
  const n = states.length;
  if (n === 0) return positions;

  const paddingX = 80;
  const paddingY = 80;
  const usableWidth = width - paddingX * 2;
  const usableHeight = height - paddingY * 2;
  const centerX = width / 2;
  const centerY = height / 2;

  if (n === 1) {
    positions[states[0]] = { id: states[0], x: centerX, y: centerY };
    return positions;
  }

  if (n === 2) {
    positions[states[0]] = { id: states[0], x: centerX - usableWidth * 0.28, y: centerY };
    positions[states[1]] = { id: states[1], x: centerX + usableWidth * 0.28, y: centerY };
    return positions;
  }

  if (n === 3) {
    const r = Math.min(usableWidth, usableHeight) * 0.4;
    states.forEach((s, i) => {
      // Rotate so initial state starts on left
      const angle = (2 * Math.PI * i) / n + Math.PI;
      positions[s] = {
        id: s,
        x: Math.round(centerX + r * Math.cos(angle)),
        y: Math.round(centerY + r * Math.sin(angle)),
      };
    });
    return positions;
  }

  if (n === 4) {
    const rx = usableWidth * 0.38;
    const ry = usableHeight * 0.36;
    // Put in nice rectangle: top-left, top-right, bottom-right, bottom-left
    positions[states[0]] = { id: states[0], x: centerX - rx, y: centerY - ry };
    positions[states[1]] = { id: states[1], x: centerX + rx, y: centerY - ry };
    positions[states[2]] = { id: states[2], x: centerX + rx, y: centerY + ry };
    positions[states[3]] = { id: states[3], x: centerX - rx, y: centerY + ry };
    return positions;
  }

  // For 5 to 12 states: circular or grid layout
  if (n <= 8) {
    const radius = Math.min(usableWidth, usableHeight) * 0.44;
    states.forEach((s, idx) => {
      const angle = (2 * Math.PI * idx) / n + Math.PI;
      positions[s] = {
        id: s,
        x: Math.round(centerX + radius * Math.cos(angle)),
        y: Math.round(centerY + radius * Math.sin(angle)),
      };
    });
    return positions;
  }

  // Grid layout for larger product state graphs (e.g. 3x3 = 9 states)
  const cols = Math.ceil(Math.sqrt(n));
  const rows = Math.ceil(n / cols);
  const stepX = usableWidth / Math.max(1, cols - 1);
  const stepY = usableHeight / Math.max(1, rows - 1);

  states.forEach((s, idx) => {
    const c = idx % cols;
    const r = Math.floor(idx / cols);
    positions[s] = {
      id: s,
      x: Math.round(paddingX + c * stepX),
      y: Math.round(paddingY + r * stepY),
    };
  });

  return positions;
}

/**
 * Computes SVG path strings and label positions for directed edges
 */
export function computeEdgesLayout(
  transitions: Record<string, Record<string, string>>,
  positions: Record<string, NodePosition>,
  nodeRadius: number = 26
): EdgeLayout[] {
  // Aggregate transitions between same (from, to) pair into single combined edge (e.g. "0, 1")
  const edgeMap = new Map<string, { fromId: string; toId: string; symbols: string[] }>();

  for (const [fromId, symbolMap] of Object.entries(transitions)) {
    for (const [symbol, toId] of Object.entries(symbolMap)) {
      if (!positions[fromId] || !positions[toId]) continue;
      const key = `${fromId}->${toId}`;
      if (!edgeMap.has(key)) {
        edgeMap.set(key, { fromId, toId, symbols: [symbol] });
      } else {
        const existing = edgeMap.get(key)!;
        if (!existing.symbols.includes(symbol)) {
          existing.symbols.push(symbol);
        }
      }
    }
  }

  const results: EdgeLayout[] = [];

  for (const edge of edgeMap.values()) {
    const { fromId, toId, symbols } = edge;
    const pFrom = positions[fromId];
    const pTo = positions[toId];

    if (!pFrom || !pTo) continue;

    // Self loop
    if (fromId === toId) {
      const x = pFrom.x;
      const y = pFrom.y;
      // Loop upwards
      const loopHeight = 44;
      const loopWidth = 24;
      const startX = x - 12;
      const startY = y - nodeRadius + 3;
      const endX = x + 12;
      const endY = y - nodeRadius + 3;

      const pathD = `M ${startX} ${startY} C ${x - loopWidth} ${y - nodeRadius - loopHeight}, ${x + loopWidth} ${y - nodeRadius - loopHeight}, ${endX} ${endY}`;
      results.push({
        fromId,
        toId,
        symbols,
        pathD,
        labelX: x,
        labelY: y - nodeRadius - loopHeight + 8,
        isSelfLoop: true,
        isCurved: true,
      });
      continue;
    }

    // Check if reverse edge exists (A -> B and B -> A)
    const reverseKey = `${toId}->${fromId}`;
    const hasReverse = edgeMap.has(reverseKey);

    const dx = pTo.x - pFrom.x;
    const dy = pTo.y - pFrom.y;
    const dist = Math.hypot(dx, dy);

    if (dist < 1) continue;

    const unitX = dx / dist;
    const unitY = dy / dist;
    const perpX = -unitY;
    const perpY = unitX;

    if (!hasReverse) {
      // Straight line
      const startX = pFrom.x + unitX * nodeRadius;
      const startY = pFrom.y + unitY * nodeRadius;
      const endX = pTo.x - unitX * (nodeRadius + 4);
      const endY = pTo.y - unitY * (nodeRadius + 4);

      const pathD = `M ${startX} ${startY} L ${endX} ${endY}`;
      const midX = (startX + endX) / 2;
      const midY = (startY + endY) / 2;

      // Slight perpendicular offset for text so it sits off the line
      const labelX = midX + perpX * 12;
      const labelY = midY + perpY * 12;

      results.push({
        fromId,
        toId,
        symbols,
        pathD,
        labelX,
        labelY,
        isSelfLoop: false,
        isCurved: false,
      });
    } else {
      // Curved arc to prevent collision with reverse edge
      const curveOffset = Math.min(32, Math.max(20, dist * 0.18));
      const midX = (pFrom.x + pTo.x) / 2 + perpX * curveOffset;
      const midY = (pFrom.y + pTo.y) / 2 + perpY * curveOffset;

      // Calculate tangent points to node circles
      const startX = pFrom.x + unitX * (nodeRadius * 0.8) + perpX * (nodeRadius * 0.5);
      const startY = pFrom.y + unitY * (nodeRadius * 0.8) + perpY * (nodeRadius * 0.5);
      const endX = pTo.x - unitX * (nodeRadius * 0.8) + perpX * (nodeRadius * 0.5);
      const endY = pTo.y - unitY * (nodeRadius * 0.8) + perpY * (nodeRadius * 0.5);

      const pathD = `M ${startX} ${startY} Q ${midX} ${midY} ${endX} ${endY}`;

      results.push({
        fromId,
        toId,
        symbols,
        pathD,
        labelX: midX,
        labelY: midY,
        isSelfLoop: false,
        isCurved: true,
      });
    }
  }

  return results;
}
