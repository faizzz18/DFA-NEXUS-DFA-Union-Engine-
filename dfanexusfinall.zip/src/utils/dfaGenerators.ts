import { DFA } from '../types/automata';

const copy = <T,>(value: T): T => JSON.parse(JSON.stringify(value)) as T;

function makeDFA(
  id: string,
  name: string,
  description: string,
  alphabet: string[],
  states: string[],
  initialState: string,
  finalStates: string[],
  transitions: Record<string, Record<string, string>>,
): DFA {
  return { id, name, description, alphabet: [...alphabet], states, initialState, finalStates, transitions };
}

export function complementDFA(dfa: DFA, label = `NOT (${dfa.name})`): DFA {
  return {
    ...copy(dfa),
    id: `${dfa.id}_not`,
    name: label,
    description: `L = Σ* − (${dfa.description})`,
    finalStates: dfa.states.filter((state) => !dfa.finalStates.includes(state)),
  };
}

export function createStartsWithDFA(symbols: string[], alphabet: string[], label: string): DFA {
  const pattern = [...symbols];
  const states = ['start', ...pattern.map((_, index) => `matched_${index + 1}`), 'dead'];
  const transitions: Record<string, Record<string, string>> = {};
  transitions.start = {};
  for (const symbol of alphabet) transitions.start[symbol] = symbol === pattern[0] ? (pattern.length === 1 ? 'matched_1' : 'matched_1') : 'dead';
  for (let i = 1; i <= pattern.length; i++) {
    const state = `matched_${i}`;
    transitions[state] = i === pattern.length
      ? Object.fromEntries(alphabet.map((symbol) => [symbol, state]))
      : Object.fromEntries(alphabet.map((symbol) => [symbol, symbol === pattern[i] ? `matched_${i + 1}` : 'dead']));
  }
  transitions.dead = Object.fromEntries(alphabet.map((symbol) => [symbol, 'dead']));
  return makeDFA(
    `starts_${pattern.join('')}`,
    label,
    `L = { w | w starts with ${pattern.join('') || 'ε'} }`,
    alphabet,
    states,
    'start',
    [`matched_${pattern.length}`],
    transitions,
  );
}

export function createEndsWithDFA(pattern: string[], alphabet: string[], label: string): DFA {
  const length = pattern.length;
  const states = Array.from({ length: length + 1 }, (_, index) => `suffix_${index}`);
  const transitions: Record<string, Record<string, string>> = {};
  const nextSuffix = (stateLength: number, symbol: string): number => {
    const candidate = pattern.slice(0, stateLength).concat(symbol);
    for (let size = Math.min(length, candidate.length); size >= 0; size--) {
      const suffix = candidate.slice(candidate.length - size).join('');
      if (pattern.slice(0, size).join('') === suffix) return size;
    }
    return 0;
  };
  for (let stateLength = 0; stateLength <= length; stateLength++) {
    transitions[`suffix_${stateLength}`] = Object.fromEntries(
      alphabet.map((symbol) => [symbol, `suffix_${nextSuffix(stateLength, symbol)}`]),
    );
  }
  return makeDFA(
    `ends_${pattern.join('')}`,
    label,
    `L = { w | w ends with ${pattern.join('') || 'ε'} }`,
    alphabet,
    states,
    'suffix_0',
    ['suffix_' + length],
    transitions,
  );
}

export function createContainsSubstringDFA(pattern: string[], alphabet: string[], label: string): DFA {
  const length = pattern.length;
  const states = Array.from({ length: length + 1 }, (_, index) => `matched_${index}`);
  const transitions: Record<string, Record<string, string>> = {};
  for (let stateLength = 0; stateLength < length; stateLength++) {
    transitions[`matched_${stateLength}`] = {};
    for (const symbol of alphabet) {
      const candidate = pattern.slice(0, stateLength).concat(symbol);
      let next = 0;
      for (let size = Math.min(length, candidate.length); size >= 0; size--) {
        const suffix = candidate.slice(candidate.length - size).join('');
        if (pattern.slice(0, size).join('') === suffix) {
          next = size;
          break;
        }
      }
      transitions[`matched_${stateLength}`][symbol] = `matched_${next}`;
    }
  }
  transitions[`matched_${length}`] = Object.fromEntries(alphabet.map((symbol) => [symbol, `matched_${length}`]));
  return makeDFA(
    `contains_${pattern.join('')}`,
    label,
    `L = { w | ${pattern.join('')} occurs in w }`,
    alphabet,
    states,
    'matched_0',
    [`matched_${length}`],
    transitions,
  );
}

export function createLengthModuloDFA(alphabet: string[], modulus: number, residue: number, label: string): DFA {
  const states = Array.from({ length: modulus }, (_, index) => `length_${index}`);
  const transitions = Object.fromEntries(
    states.map((state, index) => [state, Object.fromEntries(alphabet.map((symbol) => [symbol, `length_${(index + 1) % modulus}`]))]),
  );
  return makeDFA(`length_mod_${modulus}_${residue}`, label, `L = { w | |w| mod ${modulus} = ${residue} }`, alphabet, states, 'length_0', [`length_${residue}`], transitions);
}

export function createCountModuloDFA(alphabet: string[], countedSymbol: string, modulus: number, residue: number, label: string): DFA {
  const states = Array.from({ length: modulus }, (_, index) => `count_${index}`);
  const transitions = Object.fromEntries(
    states.map((state, index) => [state, Object.fromEntries(alphabet.map((symbol) => [symbol, `count_${(index + (symbol === countedSymbol ? 1 : 0)) % modulus}`]))]),
  );
  return makeDFA(`count_${countedSymbol}_mod_${modulus}_${residue}`, label, `L = { w | count(${countedSymbol}) mod ${modulus} = ${residue} }`, alphabet, states, 'count_0', [`count_${residue}`], transitions);
}

export function createDivisibilityDFA(alphabet: string[], base: number, divisor: number, label: string): DFA {
  const states = Array.from({ length: divisor }, (_, index) => `remainder_${index}`);
  const transitions = Object.fromEntries(
    states.map((state, remainder) => [
      state,
      Object.fromEntries(alphabet.map((symbol) => [symbol, `remainder_${(remainder * base + Number(symbol)) % divisor}`])),
    ]),
  );
  return makeDFA(`divisible_by_${base}_${divisor}`, label, `L = { w | numeric value(w) mod ${divisor} = 0 }`, alphabet, states, 'remainder_0', ['remainder_0'], transitions);
}

export function createLastDigitDFA(alphabet: string[], acceptedDigits: string[], label: string): DFA {
  const states = ['start', ...alphabet.map((symbol) => `last_${symbol}`)];
  const transitions: Record<string, Record<string, string>> = {
    start: Object.fromEntries(alphabet.map((symbol) => [symbol, `last_${symbol}`])),
  };
  for (const stateSymbol of alphabet) {
    transitions[`last_${stateSymbol}`] = Object.fromEntries(alphabet.map((symbol) => [symbol, `last_${symbol}`]));
  }
  return makeDFA(`last_digit_${acceptedDigits.join('')}`, label, `L = { w | the final digit is in {${acceptedDigits.join(', ')}} }`, alphabet, states, 'start', acceptedDigits.map((digit) => `last_${digit}`), transitions);
}

export function createExactStringDFA(word: string, alphabet: string[], label: string): DFA {
  const states = Array.from({ length: word.length + 2 }, (_, index) => index === word.length + 1 ? 'dead' : `prefix_${index}`);
  const transitions: Record<string, Record<string, string>> = {};
  for (let index = 0; index <= word.length; index++) {
    transitions[`prefix_${index}`] = Object.fromEntries(alphabet.map((symbol) => [symbol, symbol === word[index] ? `prefix_${index + 1}` : 'dead']));
  }
  transitions[`prefix_${word.length + 1}`] = Object.fromEntries(alphabet.map((symbol) => [symbol, 'dead']));
  transitions.dead = Object.fromEntries(alphabet.map((symbol) => [symbol, 'dead']));
  return makeDFA(`exact_${word}`, label, `L = {${word}}`, alphabet, states, 'prefix_0', [`prefix_${word.length}`], transitions);
}

export function combineDFAs(left: DFA, right: DFA, mode: 'union' | 'intersection' | 'difference' | 'symmetric_difference', label: string): DFA {
  const states = left.states.flatMap((leftState) => right.states.map((rightState) => `(${leftState}, ${rightState})`));
  const transitions: Record<string, Record<string, string>> = {};
  for (const leftState of left.states) {
    for (const rightState of right.states) {
      const state = `(${leftState}, ${rightState})`;
      transitions[state] = Object.fromEntries(left.alphabet.map((symbol) => [`${symbol}`, `(${left.transitions[leftState][symbol]}, ${right.transitions[rightState][symbol]})`]));
    }
  }
  const accepts = (leftState: string, rightState: string): boolean => {
    const a = left.finalStates.includes(leftState);
    const b = right.finalStates.includes(rightState);
    if (mode === 'union') return a || b;
    if (mode === 'intersection') return a && b;
    if (mode === 'difference') return a && !b;
    return a !== b;
  };
  const finalStates = left.states.flatMap((leftState) => right.states.filter((rightState) => accepts(leftState, rightState)).map((rightState) => `(${leftState}, ${rightState})`));
  return makeDFA(`combine_${left.id}_${right.id}_${mode}`, label, `Constructed from ${left.name} and ${right.name}`, left.alphabet, states, `(${left.initialState}, ${right.initialState})`, finalStates, transitions);
}
