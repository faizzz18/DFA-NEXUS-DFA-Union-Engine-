import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight,
  Atom,
  BookOpenText,
  CheckCircle2,
  ChevronRight,
  CircleDot,
  Download,
  FlaskConical,
  Layers3,
  ListChecks,
  PencilRuler,
  Play,
  SlidersHorizontal,
  Table2,
  Zap,
} from 'lucide-react';
import { DFA, OperationMode, ProductDFA, AlphabetType } from './types/automata';
import { PRESET_EXAMPLES } from './data/presets';
import { DFA_LANGUAGE_LIBRARY } from './data/dfaLibrary';
import { areAlphabetsCompatible, computeProductDFA, validateDFA } from './utils/automataEngine';
import { TopNav } from './components/TopNav';
import { AutomataCanvas } from './components/AutomataCanvas';
import { ParallelSimulator } from './components/ParallelSimulator';
import { ProductTransitionTable } from './components/ProductTransitionTable';
import { DFAEditor } from './components/DFAEditor';
import { BatchTester } from './components/BatchTester';
import { TheoryGuide } from './components/TheoryGuide';
import { ExportModal } from './components/ExportModal';
import { SplashScreen } from './components/SplashScreen';
import { LanguagePairSelector } from './components/LanguagePairSelector';

type WorkspaceView = 'simulation' | 'matrix' | 'batch' | 'editor' | 'theory';

const workspaceItems: Array<{
  id: WorkspaceView;
  label: string;
  shortLabel: string;
  description: string;
  icon: React.ElementType;
}> = [
  { id: 'simulation', label: 'Simulator', shortLabel: 'Run', description: 'Trace one string across three machines.', icon: Play },
  { id: 'matrix', label: 'Transition table', shortLabel: 'Table', description: 'Inspect the product DFA row by row.', icon: Table2 },
  { id: 'batch', label: 'Batch tests', shortLabel: 'Test', description: 'Compare a set of strings at once.', icon: ListChecks },
  { id: 'editor', label: 'DFA editor', shortLabel: 'Build', description: 'Shape the languages you want to combine.', icon: PencilRuler },
  { id: 'theory', label: 'Theory guide', shortLabel: 'Learn', description: 'Connect the visual result to the proof.', icon: BookOpenText },
];

const operationOptions: Array<{ value: OperationMode; label: string; symbol: string }> = [
  { value: 'union', label: 'Union', symbol: '∪' },
  { value: 'intersection', label: 'Intersect', symbol: '∩' },
  { value: 'difference', label: 'Difference', symbol: '∖' },
  { value: 'symmetric_difference', label: 'XOR', symbol: '△' },
];

export default function App() {
  const [selectedPresetId, setSelectedPresetId] = useState<string>(PRESET_EXAMPLES[0].id);
  const [m1, setM1] = useState<DFA>(PRESET_EXAMPLES[0].m1);
  const [m2, setM2] = useState<DFA>(PRESET_EXAMPLES[0].m2);
  const [selectedM1Id, setSelectedM1Id] = useState<string>(PRESET_EXAMPLES[0].m1.id);
  const [selectedM2Id, setSelectedM2Id] = useState<string>(PRESET_EXAMPLES[0].m2.id);
  const [alphabetFilter, setAlphabetFilter] = useState<'all' | AlphabetType>('all');
  const [operationMode, setOperationMode] = useState<OperationMode>('union');
  const [reachableOnly, setReachableOnly] = useState<boolean>(true);
  const [activeView, setActiveView] = useState<WorkspaceView>('simulation');
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [showSplash, setShowSplash] = useState(true);
  const [activeStates, setActiveStates] = useState<{
    m1State?: string;
    m2State?: string;
    productState?: string;
    activeTransition?: {
      m1?: { from: string; to: string; symbol: string };
      m2?: { from: string; to: string; symbol: string };
      product?: { from: string; to: string; symbol: string };
    };
  }>({});

  const alphabetMismatch = !areAlphabetsCompatible(m1, m2);

  const currentPreset = PRESET_EXAMPLES.find((preset) => preset.id === selectedPresetId) ?? PRESET_EXAMPLES[0];
  const activeWorkspace = workspaceItems.find((item) => item.id === activeView) ?? workspaceItems[0];
  const selectedLanguage1 = DFA_LANGUAGE_LIBRARY.find((language) => language.id === selectedM1Id);
  const selectedLanguage2 = DFA_LANGUAGE_LIBRARY.find((language) => language.id === selectedM2Id);
  const recommendedTestStrings = useMemo(() => selectedLanguage1 && selectedLanguage2
    ? Array.from(new Set([...selectedLanguage1.examples, ...selectedLanguage1.nonExamples, ...selectedLanguage2.examples, ...selectedLanguage2.nonExamples])).slice(0, 14)
    : currentPreset.recommendedTestStrings, [selectedLanguage1, selectedLanguage2, currentPreset.recommendedTestStrings]);
  const m1Validation = useMemo(() => validateDFA(m1), [m1]);
  const m2Validation = useMemo(() => validateDFA(m2), [m2]);
  const canBuildProduct = !alphabetMismatch && m1Validation.isValid && m2Validation.isValid && m1Validation.warnings.length === 0 && m2Validation.warnings.length === 0;
  const productDfa: ProductDFA = useMemo(
    () => computeProductDFA(m1, alphabetMismatch ? m1 : m2, operationMode, reachableOnly),
    [m1, m2, alphabetMismatch, operationMode, reachableOnly]
  );
  const currentOperation = operationOptions.find((option) => option.value === operationMode) ?? operationOptions[0];

  useEffect(() => {
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const timer = window.setTimeout(() => setShowSplash(false), reducedMotion ? 250 : 1350);
    return () => window.clearTimeout(timer);
  }, []);

  const handleSelectPreset = (presetId: string) => {
    const found = PRESET_EXAMPLES.find((preset) => preset.id === presetId);
    if (!found) return;
    setSelectedPresetId(presetId);
    setM1(found.m1);
    setM2(found.m2);
    setSelectedM1Id(found.m1.id);
    setSelectedM2Id(found.m2.id);
    setActiveStates({});
  };

  const handleSelectLanguage = (slot: 'm1' | 'm2', id: string) => {
    const selected = DFA_LANGUAGE_LIBRARY.find((language) => language.id === id);
    if (!selected) return;
    if (slot === 'm1') {
      setSelectedM1Id(id);
      setM1({ ...selected });
    } else {
      setSelectedM2Id(id);
      setM2({ ...selected });
    }
    setSelectedPresetId('custom-language-pair');
    setActiveStates({});
  };

  const handleAlphabetFilterChange = (filter: 'all' | AlphabetType) => {
    setAlphabetFilter(filter);
    if (filter === 'all') return;
    const compatible = DFA_LANGUAGE_LIBRARY.filter((language) => language.alphabetType === filter);
    if (compatible.length === 0) return;
    if (m1.alphabet.length !== compatible[0].alphabet.length) handleSelectLanguage('m1', compatible[0].id);
    if (m2.alphabet.length !== compatible[0].alphabet.length) handleSelectLanguage('m2', compatible[1]?.id ?? compatible[0].id);
  };

  const handleRandomPair = () => {
    const pool = DFA_LANGUAGE_LIBRARY.filter((language) => alphabetFilter === 'all' || language.alphabetType === alphabetFilter);
    const grouped = Array.from(new Set(pool.map((language) => language.alphabetType))).map((type) => pool.filter((language) => language.alphabetType === type));
    const compatiblePool = grouped.find((group) => group.length > 1) ?? pool;
    if (compatiblePool.length < 2) return;
    const firstIndex = Math.floor(Math.random() * compatiblePool.length);
    let secondIndex = Math.floor(Math.random() * compatiblePool.length);
    if (secondIndex === firstIndex) secondIndex = (secondIndex + 1) % compatiblePool.length;
    handleSelectLanguage('m1', compatiblePool[firstIndex].id);
    handleSelectLanguage('m2', compatiblePool[secondIndex].id);
  };

  const handleSwapLanguages = () => {
    const previousM1 = m1;
    const previousM1Id = selectedM1Id;
    setM1(m2);
    setM2(previousM1);
    setSelectedM1Id(selectedM2Id);
    setSelectedM2Id(previousM1Id);
    setSelectedPresetId('custom-language-pair');
    setActiveStates({});
  };

  const handleNextPreset = () => {
    const currentIndex = PRESET_EXAMPLES.findIndex((preset) => preset.id === selectedPresetId);
    const nextIndex = (currentIndex + 1) % PRESET_EXAMPLES.length;
    handleSelectPreset(PRESET_EXAMPLES[nextIndex].id);
  };

  return (
    <div className="app-shell" aria-busy={showSplash}>
      <SplashScreen visible={showSplash} />
      <TopNav activeView={activeView} onSelectView={setActiveView} onOpenExport={() => setIsExportOpen(true)} />

      <main className="app-main">
        <section className="hero-card" aria-labelledby="app-title">
          <div className="hero-copy">
            <div className="eyebrow"><span className="live-dot" /> Automata lab <span className="eyebrow-divider">/</span> regular languages</div>
            <h1 id="app-title">See union logic <span>run in real time.</span></h1>
            <p className="hero-description">
              Trace the same input through two DFAs, then watch their cross-product resolve the language operation one symbol at a time.
            </p>
            <div className="hero-actions">
              <button type="button" className="primary-action" onClick={() => setActiveView('simulation')}>
                <Play size={15} fill="currentColor" />
                Run an experiment
                <ArrowRight size={15} />
              </button>
              <button type="button" className="text-action" onClick={() => setActiveView('theory')}>
                <BookOpenText size={15} />
                Read the idea first
              </button>
            </div>
          </div>
          <div className="hero-visual" aria-hidden="true">
            <div className="orbit orbit-one" />
            <div className="orbit orbit-two" />
            <div className="orbit-node node-cyan"><span>q</span></div>
            <div className="orbit-node node-amber"><span>p</span></div>
            <div className="orbit-node node-violet"><Atom size={23} /></div>
            <div className="formula-chip formula-top">δ((q, p), a)</div>
            <div className="formula-chip formula-bottom">F = F₁ ∪ F₂</div>
          </div>
        </section>

        <section className="stats-strip" aria-label="Current automata summary">
          <div className="stat-card stat-cyan">
            <span className="stat-label"><CircleDot size={13} /> Language 1</span>
            <strong>{m1.states.length}<small> states</small></strong>
            <span className="stat-meta">{m1.finalStates.length} accepting · Σ = {'{'}{m1.alphabet.join(', ')}{'}'}</span>
          </div>
          <div className="stat-card stat-amber">
            <span className="stat-label"><CircleDot size={13} /> Language 2</span>
            <strong>{m2.states.length}<small> states</small></strong>
            <span className="stat-meta">{m2.finalStates.length} accepting · Σ = {'{'}{m2.alphabet.join(', ')}{'}'}</span>
          </div>
          <div className="stat-card stat-violet">
            <span className="stat-label"><Layers3 size={13} /> Product machine</span>
              <strong>{canBuildProduct ? productDfa.states.length : '—'}<small>{canBuildProduct ? ' reachable' : ' blocked'}</small></strong>
              <span className="stat-meta">{canBuildProduct ? `of ${productDfa.allCartesianStatesCount} cartesian states` : 'Resolve selection to build'}</span>
          </div>
          <div className="stat-card stat-mint">
            <span className="stat-label"><CheckCircle2 size={13} /> Model health</span>
              <strong>{canBuildProduct ? 'Ready' : 'Review'}</strong>
            <span className="stat-meta">{currentOperation.label} mode · live computation</span>
          </div>
        </section>

        <section className="scenario-card" aria-labelledby="scenario-title">
          <div className="scenario-topline">
            <div>
              <span className="section-kicker"><FlaskConical size={13} /> Current experiment</span>
              <h2 id="scenario-title">Choose two languages to explore</h2>
              <p className="scenario-lede">Select any supported DFA for M₁ and M₂. The product machine updates from your independent choices.</p>
            </div>
            <span className="category-badge">{DFA_LANGUAGE_LIBRARY.length} DFAs</span>
          </div>

          <LanguagePairSelector
            library={DFA_LANGUAGE_LIBRARY}
            selectedM1Id={selectedM1Id}
            selectedM2Id={selectedM2Id}
            alphabetFilter={alphabetFilter}
            onAlphabetFilterChange={handleAlphabetFilterChange}
            onSelectM1={(id) => handleSelectLanguage('m1', id)}
            onSelectM2={(id) => handleSelectLanguage('m2', id)}
            onRandomPair={handleRandomPair}
            onSwap={handleSwapLanguages}
          />

          <div className="featured-row">
            <div className="featured-select">
              <span className="control-label">Featured examples</span>
              <div className="select-shell">
                <select id="preset-select" value={PRESET_EXAMPLES.some((preset) => preset.id === selectedPresetId) ? selectedPresetId : ''} onChange={(event) => event.target.value && handleSelectPreset(event.target.value)}>
                  <option value="">Choose an existing pair…</option>
                  {PRESET_EXAMPLES.map((preset) => <option key={preset.id} value={preset.id}>{preset.title}</option>)}
                </select>
                <ChevronRight size={16} />
              </div>
            </div>
            <button type="button" className="next-scenario" onClick={handleNextPreset}>Next example <ChevronRight size={15} /></button>
            <span className="featured-summary">{PRESET_EXAMPLES.some((preset) => preset.id === selectedPresetId) ? currentPreset.summary : 'Custom pair selected from the DFA language library.'}</span>
          </div>

          <div className="scenario-controls">
            <div className="operation-controls operation-controls-wide">
              <span className="control-label"><SlidersHorizontal size={13} /> Operation</span>
              <div className="segmented-control" role="group" aria-label="Product operation">
                {operationOptions.map((option) => <button key={option.value} type="button" className={operationMode === option.value ? 'segment active' : 'segment'} onClick={() => setOperationMode(option.value)} title={option.label}><span>{option.symbol}</span><small>{option.label}</small></button>)}
              </div>
              <label className="reachable-toggle"><input type="checkbox" checked={reachableOnly} onChange={(event) => setReachableOnly(event.target.checked)} /><span>Reachable only</span></label>
            </div>
          </div>
        </section>

        <section className="workspace-section" aria-labelledby="workspace-title">
          <div className="workspace-header">
            <div>
              <span className="section-kicker"><Zap size={13} /> Workspace</span>
              <h2 id="workspace-title">{activeWorkspace.label}</h2>
              <p>{activeWorkspace.description}</p>
            </div>
            <div className="workspace-status"><span className="live-dot" /> Live model</div>
          </div>

          <div className="workspace-panel">
            {!canBuildProduct && <div className="compatibility-warning" role="alert">
              <strong>Alphabet mismatch or incomplete DFA</strong>
              {alphabetMismatch ? <p>M₁ accepts {`{${m1.alphabet.join(', ')}}`} while M₂ accepts {`{${m2.alphabet.join(', ')}}`}. Choose two DFAs from the same alphabet for a valid synchronous product.</p> : <p>Complete both DFA transition tables before constructing the product machine. The editor can help fill missing transitions.</p>}
            </div>}
            {canBuildProduct && <>
            {activeView === 'simulation' && (
              <div className="feature-stack">
                <ParallelSimulator m1={m1} m2={m2} productDfa={productDfa} onActiveStateChange={setActiveStates} quickTestStrings={recommendedTestStrings} />
                <div className="canvas-heading">
                  <div><span className="section-kicker">Live topology</span><h3>Three machines. One decision.</h3><p>Active states pulse as symbols are processed. Drag nodes to rearrange a graph.</p></div>
                  <span className="mini-note">{productDfa.states.length} states in view</span>
                </div>
                <div className="canvas-grid">
                  <AutomataCanvas dfa={m1} activeState={activeStates.m1State} activeTransition={activeStates.activeTransition?.m1} theme="cyan" title="DFA M₁ · Language 1" subtitle={m1.description} height={320} />
                  <AutomataCanvas dfa={m2} activeState={activeStates.m2State} activeTransition={activeStates.activeTransition?.m2} theme="amber" title="DFA M₂ · Language 2" subtitle={m2.description} height={320} />
                  <AutomataCanvas dfa={productDfa} activeState={activeStates.productState} activeTransition={activeStates.activeTransition?.product} theme="indigo" title={`Product · ${currentOperation.label}`} subtitle={`Cross-product · ${productDfa.states.length} reachable states`} height={320} />
                </div>
              </div>
            )}
            {activeView === 'matrix' && <ProductTransitionTable m1={m1} m2={m2} productDfa={productDfa} reachableOnly={reachableOnly} onToggleReachableOnly={setReachableOnly} operationMode={operationMode} onChangeOperationMode={setOperationMode} activeProductState={activeStates.productState} />}
            {activeView === 'batch' && <BatchTester m1={m1} m2={m2} productDfa={productDfa} recommendedStrings={recommendedTestStrings} onSelectStringForSimulation={() => setActiveView('simulation')} />}
            {activeView === 'editor' && <div className="editor-layout"><DFAEditor dfa={m1} onChange={setM1} accentColor="cyan" /><DFAEditor dfa={m2} onChange={setM2} accentColor="amber" /></div>}
            {activeView === 'theory' && <TheoryGuide m1={m1} m2={m2} productDfa={productDfa} />}
            </>}
          </div>
        </section>
      </main>

      <footer className="app-footer">
        <div><span className="footer-mark"><Atom size={14} /></span><strong>DFA Nexus</strong><span className="footer-muted">Parallel cross-product automata</span></div>
        <code>δ((q, p), a) = (δ₁(q, a), δ₂(p, a))</code>
      </footer>

      <ExportModal isOpen={isExportOpen} onClose={() => setIsExportOpen(false)} m1={m1} m2={m2} productDfa={productDfa} />
    </div>
  );
}
