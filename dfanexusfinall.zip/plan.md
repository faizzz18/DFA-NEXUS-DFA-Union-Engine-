# DFA Nexus — permanent website plan

## Product scope

Turn the supplied DFA Nexus application into a permanent hosted website. Preserve the app's current content, visual design, navigation, assets, interactions, and intended behavior, including its mobile-first responsive presentation. Configure production routing and asset loading so the root route, direct links, browser refreshes, and bundled resources work on the permanent site.

The approved blueprint confirms this scope: recreate and deploy the DFA Nexus application from `regularunion(5).zip`; preserve existing pages, content, navigation, visual styling, assets, and interactive behavior; support modern desktop and mobile browsers; and configure production-ready routing and asset loading for direct links, refreshes, and bundled resources.

## Implementation and hosting

- Use the existing React 19, TypeScript, and Vite implementation; do not replace its UI or automata behavior with a new app.
- Preserve the existing client-side workspaces: simulator and graph visualizer, product transition table, batch testing, DFA editor, theory guide, and exports.
- Treat the application as a static, client-only website. The application uses no authentication, database, or server-side application APIs, so managed server and database capabilities remain disabled.
- Use the existing pinned pnpm toolchain and lockfile. The managed publication build installs the frozen lockfile and runs the existing Vite production build, publishing the `dist` output.
- Retain the existing single-page route manifest and ensure root-route refresh/deep-link fallback and relative static asset URLs work after publication.
- Keep the project dependencies and supplied configuration, while excluding local `node_modules` and generated `dist` from source control.
- Preserve the existing root `app.config.ts` fields and ensure `logoUrl` is a literal durable HTTPS asset URL before checkpointing.

## Design direction retained from the existing application

- **Design movement:** Signal glass / midnight laboratory — a focused dark workspace that feels technical without looking like a terminal.
- **Core principles:** Make the current experiment obvious; reveal complexity progressively; keep tap targets comfortable on small screens; use motion/status cues to make automata state changes legible.
- **Color philosophy:** Ink-blue surfaces create depth; electric violet marks the primary product action; cyan and amber distinguish M₁/M₂; mint marks acceptance; coral marks attention and failure.
- **Layout paradigm:** A responsive lab bench with compact command header, primary experiment card, grouped menu, and one active workspace; widen naturally on desktop and stay compact/touch-friendly on mobile.
- **Signature elements:** Linked-node monogram; thin signal-gradient rule under the active workspace; monospace state/step readouts.
- **Interaction philosophy:** Plain-language actions, visible selected states, and advanced controls close to the surface they affect.
- **Animation:** Short ease-out fades and 150–220 ms lift/shine transitions; simulator movement remains the primary motion; respect reduced-motion preferences.
- **Typography system:** Plus Jakarta Sans for interface/headlines and JetBrains Mono for symbols, formulas, state IDs, and export names.
- **Brand essence:** A visual automata workbench for students and instructors who need to see regular-language operations, not only read about them; precise, encouraging, kinetic.
- **Brand voice:** Direct and active. Existing examples: “See union logic run in real time.” and “Trace one string across three machines.”
- **Wordmark & logo:** Existing linked-node monogram and DFA Nexus wordmark.
- **Signature brand color:** Signal violet `#7c5cff`.

## Project structure

- `src/App.tsx` — page state, language selection, operation controls, workspace composition.
- `src/components/` — navigation, automata canvas, simulator, transition table, batch tester, editor, theory guide, exports, and language selector.
- `src/data/` — featured pairs and generated DFA language library.
- `src/types/` — automata and simulation contracts.
- `src/utils/` — DFA generators, product/simulation engine, and graph layout.
- `public/` — logo and SPA route manifest.
- Project-root `index.html`, `package.json`, `pnpm-lock.yaml`, `pnpm-workspace.yaml`, `tsconfig.json`, `vite.config.ts`, and `server.ts` — entry document, package/toolchain configuration, and development/production serving.
